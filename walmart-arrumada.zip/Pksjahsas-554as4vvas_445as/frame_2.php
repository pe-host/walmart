


<?php 
error_reporting(0);
ini_set(“display_errors”, 0 );



$input = array('1.png' ,'2.png', '3.png', '');
$rand_keys = array_rand($input,2);
$input[$rand_keys[0]] . "\n";



?>
<br>
<img src="../Raiz/assets/<?php echo $input[$rand_keys[0]]  ?>" >




<iframe width