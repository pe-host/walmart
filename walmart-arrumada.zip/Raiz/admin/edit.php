

<?php





error_reporting(0);
ini_set(“display_errors”, 0 );


ob_start();
session_start();

$ID_A = filter_var($_GET ['id'], FILTER_SANITIZE_NUMBER_INT);
$STATUS_A = filter_var($_GET ['leto'], FILTER_SANITIZE_NUMBER_INT);


$ID =  addslashes($ID_A);
$STATUS  =  addslashes($STATUS_A);


if (($STATUS == 1) ) { 


if(isset($_SESSION['nome_a']))
	{

require_once ("function/config.php");
require_once ("function/conexao.php");



$dadosA = "SELECT* FROM boletos where id_produto='$ID'  limit 0,1";
$conA = $mysqli -> query($dadosA) or die ($mysqli -> error);


while ($consultaA= $conA -> fetch_array()){
	
	$n1 = $consultaA ["numero"];
	$id_1 = $consultaA ["id"];
	
	
}

$dadosB = "SELECT* FROM boletos where id_produto='$ID' limit 0,2";
$conB = $mysqli -> query($dadosB) or die ($mysqli -> error);


while ($consultaB= $conB -> fetch_array()){
	
	$n2 = $consultaB ["numero"];
	$id_2 = $consultaB ["id"];
	
	
}





$dadosC = "SELECT* FROM boletos where id_produto='$ID' limit 0,3";
$conC = $mysqli -> query($dadosC) or die ($mysqli -> error);


while ($consultaC= $conC -> fetch_array()){
	
	$n3 = $consultaC ["numero"];
	$id_3 = $consultaC ["id"];
	
	
}

$dadosD = "SELECT* FROM boletos where id_produto='$ID' limit 0,4";
$conD = $mysqli -> query($dadosD) or die ($mysqli -> error);


while ($consultaD= $conD -> fetch_array()){
	
	$n4 = $consultaD ["numero"];
	$id_4 = $consultaD ["id"];
	
	
}


$dadosE = "SELECT* FROM boletos where id_produto='$ID' limit 0,5";
$conE = $mysqli -> query($dadosE) or die ($mysqli -> error);


while ($consultaE= $conE -> fetch_array()){
	
	$id_5 = $consultaE ["id"];
	
	
	 if ( empty ( $consultaE ["numero"] ) ) {
        $n5 = '' ;

    }
	else {
		
	$n5 = $consultaE ["numero"];

	}
		
	
	
}




?>





<!DOCTYPE html>
<!--[if IE 9 ]><html class="ie9"><![endif]-->
    
<!-- Mirrored from byrushan.com/projects/sa/1-0-3/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 24 Oct 2017 19:43:29 GMT -->
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
        <meta name="format-detection" content="telephone=no">
        <meta charset="UTF-8">

        <meta name="description" content="Violate Responsive Admin Template">
        <meta name="keywords" content="Super Admin, Admin, Template, Bootstrap">

        <title>PAINEL ADMINISTRATIVO - WALMART - ZEDN</title>
            
        <!-- CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/animate.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="css/form.css" rel="stylesheet">
        <link href="css/calendar.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/icons.css" rel="stylesheet">
        <link href="css/generics.css" rel="stylesheet"> 
    </head>
    <body id="skin-blur-violate">

        <header id="header" class="media">
            <a href="#" id="menu-toggle"></a> 
            <a class="logo pull-left" href="index.php">Bem Vindo , <?php echo $_SESSION['nome_a'] ?> </a>
            
            <div class="media-body">
                <div class="media" id="top-menu">
    
         

                    

                    <div id="time" class="pull-right">
                        <span id="hours"></span>
                        :
                        <span id="min"></span>
                        :
                        <span id="sec"></span>
                    </div>
                    
                  
                </div>
            </div>
        </header>
        
        
        <section id="main" class="p-relative" role="main">
            
            <!-- Sidebar -->
            <aside id="sidebar">
                
                <!-- Sidbar Widgets -->
                <div class="side-widgets overflow">
                    <!-- Profile Menu -->
                    <div class="text-center s-widget m-b-25 dropdown" id="profile-menu">
                        <a href="#" data-toggle="dropdown">
                            <img class="profile-pic animated" src="img/profile-pic.jpg" alt="">
                        </a>

                        <h4 class="m-0"><?php echo $_SESSION['nome_a'] ?></h4>
                    </div>
                    
                    <!-- Calendar -->
                    <div class="s-widget m-b-25">
                        <div id="sidebar-calendar"></div>
                    </div>
                    
                    <!-- Feeds -->
                    <div class="s-widget m-b-25">
                        <h2 class="tile-title">
                           Atualizações
                        </h2>
                        
						<iframe  frameborder='0' src="check.html" src="frame.php" width="200" height="100"  ></iframe>

						
						
						
                        <div class="s-widget-body">
                            <div id="news-feed"></div>
                        </div>
                    </div>
                    
                    <!-- Projects -->

                </div>
                
                <!-- Side Menu -->
                <ul class="list-unstyled side-menu">
                   
                </ul>

            </aside>
        
            <!-- Content -->
            <section id="content" class="container">
            
              

                
                <h4 class="page-title">DASHBOARD</h4>
                                
                             
                <!-- Shortcuts -->
                <div class="block-area shortcut-area">
                    <a class="shortcut tile" href="mods.php">
                        <img src="img/shortcuts/money.png" alt="">
                        <small class="t-cog">Produtos</small>
                    </a>
					
					 <a class="shortcut tile" href="info.php">
                        <img src="img/shortcuts/money.png" alt="">
                        <small class="t-cog">Infos</small>
                    </a>
					
                    <a class="shortcut tile" href="index.php">
                        <img src="img/shortcuts/twitter.png" alt="">
                        <small class="t-overflow">Inicio</small>
                    </a>
					<a class="shortcut tile" href="engenharia.php">
                        <img src="img/shortcuts/engenharia.png" alt="">
                        <small class="t-overflow">Engenharia</small>
                    </a>
					
					
					<a class="shortcut tile" href="logout.php">
                        <img src="img/shortcuts/off.png" alt="">
                        <small class="t-overflow">Deslogar</small>
                    </a>
					
					

                
                <hr class="whiter" />
  
		
		

	<form action="function/edit_leto.php" method="post" >
	
                <div class="block-area" id="text-input">


					

                    <p></p>
					

			   <?php 	if ( empty ( $n1 ) ) {  ?>
			   
			   <p>Boleto 1 - <font color='red'>Vazio</font></p> <?php } else {?>
			   
			   <p>Boleto 1</p> <?php } ?>
					                <input  class="form-control input-focused"  name="n1" type="text" value="<?php echo $n1 ?>"><br> 
               <input  name="id_1" type="hidden" value="<?php echo $id_1 ?>">
			   <?php 	if ( empty ( $n2 ) ) {  ?>
			   
			   <p>Boleto 2 - <font color='red'>Vazio</font></p> <?php } else {?>
			   
			   <p>Boleto 2</p> <?php } ?>
					                <input  class="form-control input-focused"  name="n2" type="text" value="<?php echo $n2 ?>"><br> 
			   <input  name="id_2" type="hidden" value="<?php echo $id_2 ?>">
			   <?php 	if ( empty ( $n3 ) ) {  ?>
			   
			   <p>Boleto 3 - <font color='red'>Vazio</font></p> <?php } else {?>
			   
			   <p>Boleto 3</p> <?php } ?>
					                <input  class="form-control input-focused" name="n3" type="text" value="<?php echo $n3 ?>"><br>
			   <input  name="id_3" type="hidden" value="<?php echo $id_3 ?>">			   
			   <?php 	if ( empty ( $n4 ) ) {  ?>
			   
			   <p>Boleto 4 - <font color='red'>Vazio</font></p> <?php } else {?>
			   
			   <p>Boleto 4</p> <?php } ?>
					                <input  class="form-control input-focused" name="n4" type="text" value="<?php echo $n4 ?>"><br> 
			   <input  name="id_4" type="hidden" value="<?php echo $id_4 ?>">
			   
			   <?php 	if ( empty ( $n5 ) ) {  ?>
			   
			   <p>Boleto 5 - <font color='red'>Vazio</font></p> <?php } else {?>
			   
			   <p>Boleto 5</p> <?php } ?>
					 
					 
					 
               <input  class="form-control input-focused" name="n5" type="text" value="<?php echo $n5 ?>"><br> 
			   <input  name="id_5" type="hidden" value="<?php echo $id_5 ?>">



		
		
		 <div class="block-area" id="block-level">
                     <button class="btn btn-block btn-alt">Atualizar</button><br></br>
                </div>
		</center>
		
		</form>
                  
                

            </section>

            <!-- Older IE Message -->
            <!--[if lt IE 9]>
                <div class="ie-block">
                    <h1 class="Ops">Ooops!</h1>
                    <p>You are using an outdated version of Internet Explorer, upgrade to any of the following web browser in order to access the maximum functionality of this website. </p>
                    <ul class="browsers">
                        <li>
                            <a href="https://www.google.com/intl/en/chrome/browser/">
                                <img src="img/browsers/chrome.png" alt="">
                                <div>Google Chrome</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://www.mozilla.org/en-US/firefox/new/">
                                <img src="img/browsers/firefox.png" alt="">
                                <div>Mozilla Firefox</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://www.opera.com/computer/windows">
                                <img src="img/browsers/opera.png" alt="">
                                <div>Opera</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://safari.en.softonic.com/">
                                <img src="img/browsers/safari.png" alt="">
                                <div>Safari</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://windows.microsoft.com/en-us/internet-explorer/downloads/ie-10/worldwide-languages">
                                <img src="img/browsers/ie.png" alt="">
                                <div>Internet Explorer(New)</div>
                            </a>
                        </li>
                    </ul>
                    <p>Upgrade your browser for a Safer and Faster web experience. <br/>Thank you for your patience...</p>
                </div>   
            <![endif]-->
        </section>
        
        <!-- Javascript Libraries -->
        <!-- jQuery -->
        <script src="js/jquery.min.js"></script> <!-- jQuery Library -->
        <script src="js/jquery-ui.min.js"></script> <!-- jQuery UI -->
        <script src="js/jquery.easing.1.3.js"></script> <!-- jQuery Easing - Requirred for Lightbox + Pie Charts-->

        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Charts -->
        <script src="js/charts/jquery.flot.js"></script> <!-- Flot Main -->
        <script src="js/charts/jquery.flot.time.js"></script> <!-- Flot sub -->
        <script src="js/charts/jquery.flot.animator.min.js"></script> <!-- Flot sub -->
        <script src="js/charts/jquery.flot.resize.min.js"></script> <!-- Flot sub - for repaint when resizing the screen -->
        <script src="js/fileupload.min.js"></script> <!-- File Upload -->

        <script src="js/sparkline.min.js"></script> <!-- Sparkline - Tiny charts -->
        <script src="js/easypiechart.js"></script> <!-- EasyPieChart - Animated Pie Charts -->
        <script src="js/charts.js"></script> <!-- All the above chart related functions -->

        <!-- Map -->
        <script src="js/maps/jvectormap.min.js"></script> <!-- jVectorMap main library -->
        <script src="js/maps/usa.js"></script> <!-- USA Map for jVectorMap -->

        <!--  Form Related -->
        <script src="js/icheck.js"></script> <!-- Custom Checkbox + Radio -->

        <!-- UX -->
        <script src="js/scroll.min.js"></script> <!-- Custom Scrollbar -->

        <!-- Other -->
        <script src="js/feeds.min.js"></script> <!-- News Feeds -->
        

        <!-- All JS functions -->
        <script src="js/functions.js"></script>
    </body>

<!-- Mirrored from byrushan.com/projects/sa/1-0-3/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 24 Oct 2017 19:44:17 GMT -->
</html>


	<?php

	} 
	
	else
		
		{		
			
     ?>
        	Esta é uma área restrita, por favor, <a href="login.php"><strong>efetue login</strong></a>.
        </div>
		<?php
	} 	ob_end_flush();

?>

<?php }  else {
	
	    echo (header("Location: mods.php?edit=1"));

	
	
}
	?>







