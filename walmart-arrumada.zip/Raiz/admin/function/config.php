
<?php


$dbhost = 'localhost'; // endereco do servidor de banco de dados
$dbuser = 'americ53_america'; // login do banco de dados
$dbpass = 'Zedn1@'; // senha
$dbname = 'americ53_america'; // nome do banco de dados a ser usado

?>