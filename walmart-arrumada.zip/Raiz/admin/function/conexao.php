

<?php




$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($mysqli -> connect_errno)
	echo "A conexao falhou: (".$mysqli -> connect_errno.")".$mysqli -> connect_error;



?>


