<?php 


ob_start();
session_start();


require_once ("config.php");
require_once ("conexao.php");

error_reporting(0);
ini_set(“display_errors”, 0 );


$n1 =  addslashes($_POST["n1"]);
$n2 =  addslashes($_POST["n2"]);
$n3 =  addslashes($_POST["n3"]);
$n4 =  addslashes($_POST["n4"]);
$n5 =  addslashes($_POST["n5"]);
$id_1 =  addslashes($_POST["id_1"]);
$id_2 =  addslashes($_POST["id_2"]);
$id_3 =  addslashes($_POST["id_3"]);
$id_4 =  addslashes($_POST["id_4"]);
$id_5 =  addslashes($_POST["id_5"]);
	




$sql1 = "Update boletos SET numero='$n1' where id='$id_1' " ;
$query = $mysqli->query($sql1);


$sql2 = "Update boletos SET numero='$n2' where id='$id_2' " ;
$query = $mysqli->query($sql2);



$sql3 = "Update boletos SET numero='$n3' where id='$id_3' " ;
$query = $mysqli->query($sql3);



$sql4 = "Update boletos SET numero='$n4' where id='$id_4' " ;
$query = $mysqli->query($sql4);





$sql = "Update boletos SET numero='$n5' where id='$id_5' " ;
$query = $mysqli->query($sql);

  if(!$query)
    die (header("Location: ../mods.php?status=2"));
  else
    echo (header("Location: ../mods.php?status=1"));

	
	


?>    


