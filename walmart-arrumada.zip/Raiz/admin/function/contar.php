<?php




error_reporting(0);
ini_set(“display_errors”, 0 );

require_once ("config.php");
require_once ("conexao.php");




$sql1="SELECT count(id) AS  total FROM produtos";

$result=mysqli_query($mysqli,$sql1);
$values=mysqli_fetch_assoc($result);
$produtos_add=$values['total'];


$sql2="SELECT count(id) AS  total FROM capturas";

$result2=mysqli_query($mysqli,$sql2);
$values2=mysqli_fetch_assoc($result2);
$capturas_add=$values2['total'];


$sql3="SELECT count(id) AS  total FROM capturas_boleto";

$result3=mysqli_query($mysqli,$sql3);
$values3=mysqli_fetch_assoc($result3);
$capturas_add1=$values3['total'];





?>



