<?php 


ob_start();
session_start();

require_once ("config.php");
require_once ("conexao.php");


$LINK_A = $_POST["link"];
$EMAIL_A = $_POST["email"];
$ANTI_A = $_POST["anti"];
$DESCONTO_A = $_POST["desconto"];
$VENCIMENTO_A = $_POST["vencimento"];


$LINK =  addslashes($LINK_A);
$EMAIL =  addslashes($EMAIL_A);
$ANTI =  addslashes($ANTI_A);
$DESCONTO =  addslashes($DESCONTO_A);
$VENCIMENTO =  addslashes($VENCIMENTO_A);
	





$sql = "Update configuracao SET link_site='$LINK', email='$EMAIL', anti_phising='$ANTI' , vencimento='$VENCIMENTO', desconto='$DESCONTO'  where id=1 " ;
$query = $mysqli->query($sql);

  if(!$query)
    die (header("Location: ../configuracao.php?status=2"));
  else
    echo (header("Location: ../configuracao.php?status=1"));

	
	


?>    


