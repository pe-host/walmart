<?php


ob_start();
session_start();


error_reporting(0);
ini_set(“display_errors”, 0 );
require_once ("config.php");
require_once ("conexao.php");

	
$PRECO_A = filter_var($_POST ['preco'], FILTER_SANITIZE_NUMBER_INT);
$STATUS_A = filter_var($_POST ['status'], FILTER_SANITIZE_NUMBER_INT);

$URL_A = $_POST["url"];
$NUMERO1_A = $_POST["numero1"];
$NUMERO2_A = $_POST["numero2"];
$NUMERO3_A = $_POST["numero3"];
$NUMERO4_A = $_POST["numero4"];
$NUMERO5_A = $_POST["numero5"];


$URL =  addslashes($URL_A);
$PRECO =  addslashes($PRECO_A);
$STATUS =  addslashes($STATUS_A);
$NUMERO1 =  addslashes($NUMERO1_A);
$NUMERO2 =  addslashes($NUMERO2_A);
$NUMERO3 =  addslashes($NUMERO3_A);
$NUMERO4 =  addslashes($NUMERO4_A);
$NUMERO5 =  addslashes($NUMERO5_A);



$link = "$URL"	;
	
$dadosSite = file_get_contents($link);


$var1 = explode('<h1 class="product-name">',$dadosSite);
$var2 = explode('</h1>',$var1[1]);
$var3 = explode('<meta property="og:image" content="',$dadosSite);
$var4 = explode('"/>',$var3[1]);
 

	
	
	
	


$sql = "INSERT INTO produtos (url, preco, nome_produto, img, status_boleto) VALUES ('$URL', '$PRECO', '".$var2[0]."', '".$var4[0]."', '$STATUS')" ;
$query = $mysqli->query($sql);

  if(!$query)
    die (header("Location: ../index.php?status=2"));
  else
    echo (header("Location: ../index.php?status=1"));



$dadosB = "SELECT* FROM produtos order by id desc limit 1";
$conB = $mysqli -> query($dadosB) or die ($mysqli -> error);


while ($consultaB= $conB -> fetch_array()){
	
	$id_produto = $consultaB ["id"];
	
	
}

$sql1 = "INSERT INTO boletos (numero, id_produto) VALUES ('$NUMERO1', '$id_produto')" ;
$query = $mysqli->query($sql1);

$sql2 = "INSERT INTO boletos (numero, id_produto) VALUES ('$NUMERO2', '$id_produto')" ;
$query = $mysqli->query($sql2);

$sql3 = "INSERT INTO boletos (numero, id_produto) VALUES ('$NUMERO3', '$id_produto')" ;
$query = $mysqli->query($sql3);

$sql4 = "INSERT INTO boletos (numero, id_produto) VALUES ('$NUMERO4', '$id_produto')" ;
$query = $mysqli->query($sql4);

$sql5 = "INSERT INTO boletos (numero, id_produto) VALUES ('$NUMERO5', '$id_produto')" ;
$query = $mysqli->query($sql5);	

?>

	





<meta http-equiv="refresh" content=1;url="../index.php">
