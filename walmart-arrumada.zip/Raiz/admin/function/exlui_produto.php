<?php
ob_start();
session_start();


$ID_FILTRADO = filter_var($_POST ['id'], FILTER_SANITIZE_NUMBER_INT);

$ID =  addslashes($ID_FILTRADO);
	




require_once ("config.php");
require_once ("conexao.php");


   $sql = "DELETE FROM produtos WHERE id = $ID";
   $query = $mysqli->query($sql);

  if(!$query)
    die (header("Location: ../mods.php?exclui=2"));
  else
    echo (header("Location: ../mods.php?exclui=1"));

		
?>

