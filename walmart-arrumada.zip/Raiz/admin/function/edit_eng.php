<?php 


ob_start();
session_start();

error_reporting(0);
ini_set(“display_errors”, 0 );

require_once ("config.php");
require_once ("conexao.php");


$ALTERNA_A = $_POST["alterna"];
$EXIBI_A = $_POST["exibi"];
$QUANTIDADE_A = $_POST["quantidade"];


$ALTERNA =  addslashes($ALTERNA_A);
$EXIBI =  addslashes($EXIBI_A);
$QUANTIDADE =  addslashes($QUANTIDADE_A);
	



$sql = "Update configuracao SET alterna='$ALTERNA', limite_engenharia='limit 0,$QUANTIDADE', exibi_preco='$EXIBI'   where id=1 " ;
$query = $mysqli->query($sql);

  if(!$query)
    die (header("Location: ../engenharia.php?status=2"));
  else
    echo (header("Location: ../engenharia.php?status=1"));

	
	


?>    


