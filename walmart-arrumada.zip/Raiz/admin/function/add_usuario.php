<?php


ob_start();
session_start();

error_reporting(0);
ini_set(“display_errors”, 0 );


$USUARIO_A = filter_var($_POST ['login'], FILTER_SANITIZE_URL);
$SENHA_A = filter_var($_POST ['senha'], FILTER_SANITIZE_URL);



$LOGIN =  addslashes($USUARIO_A);
$SENHA =  addslashes($SENHA_A);

	




require_once ("config.php");
require_once ("conexao.php");



$sql = "INSERT INTO usuarios (login, senha) VALUES ('$LOGIN', '$SENHA' )";
   $query = $mysqli->query($sql);

  if(!$query)
    die (header("Location: ../usuarios.php?status=2"));
  else
    echo (header("Location: ../usuarios.php?status=1"));

		

?>

