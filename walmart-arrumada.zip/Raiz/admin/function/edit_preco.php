<?php 


ob_start();
session_start();

require_once ("config.php");
require_once ("conexao.php");

error_reporting(0);
ini_set(“display_errors”, 0 );
$ID_A = filter_var($_POST ['id'], FILTER_SANITIZE_NUMBER_INT);
$PRECO_A = filter_var($_POST ['preco'], FILTER_SANITIZE_URL);
$ID_BOLETO = filter_var($_POST ['id_boleto'], FILTER_SANITIZE_URL);



$ID =  addslashes($ID_A);
$PRECO =  addslashes($PRECO_A);
$STATUS =  addslashes($_POST ['status']);
	

$sql = "Update produtos SET preco='$PRECO', status_boleto='$STATUS'  where id='$ID' ";
 $query = $mysqli->query($sql);
   

  if(!$query)
    die (header("Location: ../mods.php?config=2"));
  else
    echo (header("Location: ../mods.php?config=1"));

		





?>    


