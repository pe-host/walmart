<?php

if(isset($_POST['ver'])){


$link1 = $_POST ['link1'];
$link2 = $_POST ['link2'];


$texto = "<strong><font color='red' >Link Grande:</font><font color='white' > ".$link1."<br><br>

</font><font color='blue' >Link Curto:</font><font color='white' > ".$link2."


";

echo $texto;
}


?>


