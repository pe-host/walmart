<?php


error_reporting(0);
ini_set(“display_errors”, 0 );
				ob_start();
				session_start();

include('function/log.php');

$LOGIN_A = filter_var($_POST ['login'], FILTER_SANITIZE_URL	);
$SENHA_A = filter_var($_POST ['senha'], FILTER_SANITIZE_URL	);


$login =  addslashes($LOGIN_A);
$senha =  addslashes($SENHA_A);



$sql = mysqli_query($conexao,"select * from usuarios where login='$login' and senha='$senha' limit 1") or die("Erro");
$linhas = mysqli_num_rows($sql);
if($linhas == '')
	{
		
        echo 'Usuário não encontrado ou usuário e senha inválidos.';
       
	}
else
	{
		while($dados=mysqli_fetch_assoc($sql))
			{

				$_SESSION['nome_a'] = $dados['login'];
				header("Location: index.php");
			
		}
	}
	


	
?>


